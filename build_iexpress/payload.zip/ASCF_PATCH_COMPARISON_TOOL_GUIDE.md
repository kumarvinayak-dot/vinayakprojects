# ASCF Patch Comparison Tool
## Complete Guide for Users and Stakeholders

---

# Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Business Value & Benefits](#2-business-value--benefits)
3. [Key Features Overview](#3-key-features-overview)
4. [Technical Architecture](#4-technical-architecture)
5. [Technologies Used](#5-technologies-used)
6. [Comparison Modes Explained](#6-comparison-modes-explained)
7. [User Interface Walkthrough](#7-user-interface-walkthrough)
8. [Use Cases & Scenarios](#8-use-cases--scenarios)
9. [Multi-User & Network Access](#9-multi-user--network-access)
10. [Security Considerations](#10-security-considerations)
11. [Getting Started](#11-getting-started)
12. [FAQ](#12-faq)

---

# 1. Executive Summary

## What is the ASCF Patch Comparison Tool?

The **ASCF Patch Comparison Tool** is a web-based application designed to automate and streamline the comparison of software builds, patches, hotfixes, and release bundles. It enables development, QA, and release management teams to quickly identify differences between software versions with detailed, actionable reports.

## The Problem It Solves

| Challenge | Impact | How This Tool Helps |
|-----------|--------|---------------------|
| Manual file comparison is time-consuming | Hours spent on each release | Automated comparison in minutes |
| Human error in identifying changes | Missed files, incorrect deployments | Comprehensive automated scanning |
| Difficulty comparing nested archives | Complex EAR/WAR/JAR structures missed | Deep recursive archive inspection |
| No standardized comparison process | Inconsistent results across teams | Single tool with consistent methodology |
| Tracking version changes in JARs | Security vulnerabilities missed | Automatic version extraction and comparison |

## Key Statistics

```
┌─────────────────────────────────────────────────────────────────┐
│                    TIME SAVINGS COMPARISON                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   Manual Comparison:     4-8 hours per release                  │
│   With This Tool:        5-15 minutes per release               │
│                                                                  │
│   Time Saved:            ~95%                                   │
│   Error Reduction:       ~99%                                   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

# 2. Business Value & Benefits

## For Development Teams

| Benefit | Description |
|---------|-------------|
| **Faster Release Validation** | Verify patch contents match requirements in minutes |
| **Reduced Human Error** | Automated detection eliminates manual oversight |
| **Better Documentation** | Auto-generated reports for audit trails |
| **Easy Hotfix Verification** | Confirm only intended changes are included |

## For QA Teams

| Benefit | Description |
|---------|-------------|
| **Comprehensive Testing Scope** | Know exactly what changed to focus testing |
| **Regression Risk Assessment** | Identify files that may need regression testing |
| **Version Tracking** | Track library version changes across releases |
| **Evidence for Sign-off** | Exportable reports for test documentation |

## For Release Management

| Benefit | Description |
|---------|-------------|
| **Deployment Confidence** | Verify builds before production deployment |
| **Compliance Documentation** | Maintain audit-ready comparison records |
| **Change Impact Analysis** | Understand scope of changes at a glance |
| **Faster Go/No-Go Decisions** | Quick verification enables faster releases |

## For Management

| Benefit | Description |
|---------|-------------|
| **Cost Reduction** | Less manual effort = lower operational costs |
| **Risk Mitigation** | Reduced deployment errors and rollbacks |
| **Process Standardization** | Consistent comparison methodology |
| **Audit Readiness** | Automated documentation for compliance |

## Return on Investment (ROI)

```
┌─────────────────────────────────────────────────────────────────┐
│                      ROI CALCULATION EXAMPLE                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Assumptions:                                                    │
│    • 20 releases per year                                       │
│    • 6 hours manual comparison per release                      │
│    • Engineer cost: $75/hour                                    │
│                                                                  │
│  Manual Cost:    20 × 6 × $75 = $9,000/year                    │
│  With Tool:      20 × 0.25 × $75 = $375/year                   │
│                                                                  │
│  Annual Savings: $8,625                                         │
│  ROI:            2,200%                                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

# 3. Key Features Overview

## Feature Matrix

| Feature | Description | Benefit |
|---------|-------------|---------|
| 🔍 **Multi-Mode Comparison** | 4 specialized comparison modes | Right tool for each scenario |
| 📦 **Deep Archive Inspection** | Recursive EAR → WAR → JAR analysis | Nothing hidden in nested archives |
| 📊 **Visual HTML Reports** | Color-coded, interactive reports | Easy to understand results |
| 🔄 **Real-time Progress** | Live progress tracking with ETA | Monitor long comparisons |
| 📋 **Console Logging** | Detailed operation logs | Debug and audit trail |
| 👥 **Multi-User Support** | Session-based isolation | Team collaboration |
| 🌐 **Network Accessible** | Share with team via network | No installation needed for users |
| 📁 **File Copy Utility** | Built-in folder copy with progress | Convenient build management |
| 📈 **Size Analysis** | File and archive size comparison | Detect unexpected changes |
| ☕ **Java Decompilation** | Compare Java class internals | Deep code-level comparison |

## Supported File Types

### Archives
- **Java Archives:** `.jar`, `.war`, `.ear`
- **Compressed:** `.zip`, `.tar`, `.tar.gz`, `.tgz`
- **Linux Packages:** `.rpm` (with CPIO extraction)

### Comparison Targets
- Individual files and folders
- Nested archive structures
- Java class files (with decompilation)
- MANIFEST.MF and property files
- Any text-based configuration files

---

# 4. Technical Architecture

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              USER LAYER                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐                    │
│   │  Browser A  │    │  Browser B  │    │  Browser C  │                    │
│   │  (User 1)   │    │  (User 2)   │    │  (User 3)   │                    │
│   └──────┬──────┘    └──────┬──────┘    └──────┬──────┘                    │
│          │                  │                  │                            │
│          └──────────────────┼──────────────────┘                            │
│                             │ HTTP (Port 5000)                              │
│                             ▼                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                          APPLICATION LAYER                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                    builtin_server.py                                 │  │
│   │                 (Python ThreadingHTTPServer)                         │  │
│   │                                                                      │  │
│   │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────┐  │  │
│   │  │   Web UI Layer  │  │  Business Logic │  │  Session Manager    │  │  │
│   │  │                 │  │                 │  │                     │  │  │
│   │  │  • HTML Pages   │  │  • Comparison   │  │  • User Sessions    │  │  │
│   │  │  • JavaScript   │  │  • File Copy    │  │  • Progress Track   │  │  │
│   │  │  • CSS Styling  │  │  • Reporting    │  │  • Console Logs     │  │  │
│   │  └─────────────────┘  └────────┬────────┘  └─────────────────────┘  │  │
│   │                                │                                     │  │
│   └────────────────────────────────┼─────────────────────────────────────┘  │
│                                    │                                        │
├────────────────────────────────────┼────────────────────────────────────────┤
│                          PROCESSING LAYER                                    │
├────────────────────────────────────┼────────────────────────────────────────┤
│                                    ▼                                        │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                     folder_compare.py                                │  │
│   │                   (Core Comparison Engine)                           │  │
│   │                                                                      │  │
│   │  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐              │  │
│   │  │FolderComparer │ │NamingComparer │ │ArchiveComparer│              │  │
│   │  │               │ │               │ │               │              │  │
│   │  │ • Hash-based  │ │ • Name parse  │ │ • Deep scan   │              │  │
│   │  │ • Size check  │ │ • Version     │ │ • Nested      │              │  │
│   │  │ • Metadata    │ │   extraction  │ │   archives    │              │  │
│   │  └───────────────┘ └───────────────┘ └───────────────┘              │  │
│   │                                                                      │  │
│   │  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐              │  │
│   │  │JarManifest    │ │ RPM Handler   │ │ Report        │              │  │
│   │  │Comparer       │ │               │ │ Generator     │              │  │
│   │  │               │ │ • CPIO        │ │               │              │  │
│   │  │ • MANIFEST.MF │ │   extraction  │ │ • HTML        │              │  │
│   │  │ • Impl-Version│ │ • RPM headers │ │ • Text        │              │  │
│   │  └───────────────┘ └───────────────┘ └───────────────┘              │  │
│   │                                                                      │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                           EXTERNAL TOOLS                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│   │  CFR Decompiler │  │  Python zipfile │  │  Python tarfile │            │
│   │  (Java → Source)│  │  (ZIP/JAR/WAR)  │  │  (TAR/TGZ)      │            │
│   └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   User       │     │   Server     │     │   Comparer   │     │   Report     │
│   Request    │────▶│   Receives   │────▶│   Processes  │────▶│   Generated  │
│              │     │   & Routes   │     │   Files      │     │              │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
                                                │
                                                ▼
                     ┌──────────────────────────────────────────────────────┐
                     │                 Processing Steps                     │
                     ├──────────────────────────────────────────────────────┤
                     │  1. Validate input paths                             │
                     │  2. Scan folder/archive contents                     │
                     │  3. Calculate file hashes (MD5/SHA)                  │
                     │  4. Extract nested archives (if needed)              │
                     │  5. Compare file inventories                         │
                     │  6. Identify: Added, Removed, Modified, Unchanged    │
                     │  7. Generate HTML/Text report                        │
                     │  8. Return results to user                           │
                     └──────────────────────────────────────────────────────┘
```

## Component Descriptions

| Component | File | Responsibility |
|-----------|------|----------------|
| **HTTP Server** | `builtin_server.py` | Request handling, routing, UI serving |
| **Comparison Engine** | `folder_compare.py` | Core comparison logic and algorithms |
| **Report Generator** | `folder_compare.py` | HTML/Text report creation |
| **Session Manager** | `builtin_server.py` | Multi-user session isolation |
| **Progress Tracker** | `builtin_server.py` | Real-time progress updates |

---

# 5. Technologies Used

## Technology Stack

```
┌─────────────────────────────────────────────────────────────────┐
│                        TECHNOLOGY STACK                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    FRONTEND                              │   │
│  │                                                          │   │
│  │   HTML5        │   CSS3         │   JavaScript (ES6)    │   │
│  │   • Semantic   │   • Flexbox    │   • Fetch API         │   │
│  │   • Forms      │   • Grid       │   • DOM manipulation  │   │
│  │   • Tables     │   • Gradients  │   • Progress polling  │   │
│  │                │   • Responsive │   • Session storage   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    BACKEND                               │   │
│  │                                                          │   │
│  │   Python 3.x                                             │   │
│  │   • ThreadingHTTPServer (stdlib)                         │   │
│  │   • zipfile, tarfile (archive handling)                  │   │
│  │   • hashlib (file hashing)                               │   │
│  │   • pathlib (path operations)                            │   │
│  │   • threading (concurrent operations)                    │   │
│  │   • json (API responses)                                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                 EXTERNAL TOOLS                           │   │
│  │                                                          │   │
│  │   CFR Decompiler (Java)                                  │   │
│  │   • Java bytecode to source conversion                   │   │
│  │   • Class file analysis                                  │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Why These Technologies?

| Technology | Reason for Selection |
|------------|---------------------|
| **Python** | Cross-platform, powerful file handling, rapid development |
| **Built-in HTTP Server** | No external dependencies, easy deployment |
| **HTML/CSS/JS** | Universal browser support, no client installation |
| **Standard Library** | Minimal dependencies, reliable, well-tested |
| **CFR Decompiler** | Industry-standard Java decompilation |

## Dependencies

### Required
- Python 3.8 or higher
- Modern web browser (Chrome, Firefox, Edge)

### Optional
- CFR Decompiler JAR (for Java class comparison)
- psutil (for automatic process cleanup)

## No Installation Required for End Users

The tool runs as a web server. End users only need:
- A web browser
- Network access to the server

---

# 6. Comparison Modes Explained

## Mode 1: Full Content Comparison

**Purpose:** Complete file-by-file comparison with content verification

**How It Works:**
```
┌─────────────────┐         ┌─────────────────┐
│   Folder 1      │         │   Folder 2      │
│   (Old Build)   │         │   (New Build)   │
├─────────────────┤         ├─────────────────┤
│ file1.txt  ─────┼────┬────┼─ file1.txt      │  ✓ Identical (same hash)
│ file2.jar  ─────┼────┼────┼─ file2.jar      │  ⚠ Modified (different hash)
│ file3.xml  ─────┼────┼────┼─                │  ❌ Removed
│             ────┼────┼────┼─ file4.class    │  ✨ Added
└─────────────────┘    │    └─────────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │  Compare using  │
              │  MD5/SHA hash   │
              └─────────────────┘
```

**Best For:**
- Hotfix verification
- Release content validation
- Detecting unintended changes

**Output Shows:**
- Files only in Old Build (Removed)
- Files only in New Build (Added)
- Files with different content (Modified)
- Identical files (Unchanged)

---

## Mode 2: Naming Convention Comparison

**Purpose:** Analyze JAR/library naming patterns and version changes

**How It Works:**
```
┌─────────────────────────────────────────────────────────────────┐
│                    JAR NAME ANALYSIS                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  commons-logging-1.2.jar                                        │
│         │           │                                            │
│         │           └── Version: 1.2                            │
│         └────────────── Base Name: commons-logging              │
│                                                                  │
│  commons-logging-1.3.jar                                        │
│         │           │                                            │
│         │           └── Version: 1.3                            │
│         └────────────── Base Name: commons-logging              │
│                                                                  │
│  Result: VERSION UPGRADE DETECTED                               │
│          commons-logging: 1.2 → 1.3                             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**Best For:**
- Library version tracking
- Security update verification
- FOSS/third-party component analysis

**Output Shows:**
- Version upgrades/downgrades
- Renamed components
- New libraries added
- Libraries removed

---

## Mode 3: Archive Contents Comparison

**Purpose:** Deep inspection inside EAR, WAR, JAR, ZIP, RPM files

**How It Works:**
```
┌─────────────────────────────────────────────────────────────────┐
│                 NESTED ARCHIVE INSPECTION                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Application.ear                                                │
│  │                                                               │
│  ├── META-INF/                                                  │
│  │   └── application.xml                                        │
│  │                                                               │
│  ├── webapp.war  ◄─── Extracted and analyzed                    │
│  │   │                                                           │
│  │   ├── WEB-INF/                                               │
│  │   │   ├── web.xml                                            │
│  │   │   └── lib/                                               │
│  │   │       ├── library1.jar  ◄─── Also extracted              │
│  │   │       │   ├── com/example/Class1.class                   │
│  │   │       │   └── META-INF/MANIFEST.MF                       │
│  │   │       └── library2.jar                                   │
│  │   │                                                           │
│  │   └── index.html                                             │
│  │                                                               │
│  └── ejb.jar                                                    │
│                                                                  │
│  Depth: EAR → WAR → JAR → Class files                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**Best For:**
- Enterprise application comparison
- Deployment package verification
- Understanding complex archive structures

**Output Shows:**
- Archive inventory comparison
- Nested content differences
- Size changes at each level
- Missing/added components

---

## Mode 4: FOSS/Foundation JAR Comparison

**Purpose:** Extract and compare Implementation-Version from MANIFEST.MF

**How It Works:**
```
┌─────────────────────────────────────────────────────────────────┐
│                 MANIFEST.MF ANALYSIS                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  JAR File: log4j-core-2.17.1.jar                               │
│                                                                  │
│  META-INF/MANIFEST.MF:                                          │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ Manifest-Version: 1.0                                     │  │
│  │ Implementation-Title: Apache Log4j Core                   │  │
│  │ Implementation-Version: 2.17.1          ◄── Extracted     │  │
│  │ Implementation-Vendor: Apache Software Foundation         │  │
│  │ Bundle-Version: 2.17.1                                    │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  Comparison Result:                                             │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ log4j-core                                                │  │
│  │   Folder 1: 2.14.1  →  Folder 2: 2.17.1                  │  │
│  │   Status: UPGRADED (Security Fix)                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**Best For:**
- Security vulnerability tracking (e.g., Log4j updates)
- License compliance verification
- Foundation component auditing

**Output Shows:**
- Implementation-Version from each JAR
- Version differences highlighted
- Foundation product grouping
- Upgrade/downgrade indicators

---

## Mode Comparison Summary

| Mode | Speed | Depth | Best Use Case |
|------|-------|-------|---------------|
| Full Content | Medium | Deep | Complete verification |
| Naming Convention | Fast | Surface | Quick version check |
| Archive Contents | Slow | Very Deep | Complex packages |
| FOSS/Foundation | Fast | Targeted | Security/compliance |

---

# 7. User Interface Walkthrough

## Main Interface Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  📋 Console Output                                    [Stop and refresh]    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  📁 Old Build Path          │  📁 New Build Path                    │   │
│  │  [C:\builds\patch_v1.0    ] │  [C:\builds\patch_v1.1            ]   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  🏢 Select Application                                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  [x] ASCF    [ ] CRM    [ ] UXF                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  Mode                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  (•) Full content comparison                                         │   │
│  │  ( ) Naming convention comparison                                    │   │
│  │  ( ) Archives (.ear/.war/.zip/.rpm/.jar) content                    │   │
│  │  ( ) FOSS/Foundation (JAR Implementation-Version)                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      [ Run comparison ]                              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  📋 Copy Build Folders                                    [📋 Copy Logs]   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  (•) Copy from Old Build Path    ( ) Copy from New Build Path       │   │
│  │  Destination path: [                                            ]   │   │
│  │  [ ] Overwrite if exists                                            │   │
│  │                                                                      │   │
│  │                          [ Copy ]                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Progress Tracking Display

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         COMPARISON IN PROGRESS                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ████████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  45%        │
│                                                                              │
│  📁 Processing: lib/commons-logging-1.2.jar                                 │
│  📊 Files: 1,234 / 2,741                                                    │
│  ⏱️ ETA: 2 minutes 15 seconds                                               │
│                                                                              │
│                          [ Stop Comparison ]                                │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Report Output Example

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    COMPARISON REPORT                                         │
│                    Generated: 2024-12-11 14:30:00                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  SUMMARY                                                                    │
│  ───────────────────────────────────────────────────────────────────────   │
│  Old Build: C:\builds\ASCF_HF_v10.25.0.pb00                                │
│  New Build: C:\builds\ASCF_HF_v10.25.0.pb00_hf01                           │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │  ❌ Removed from Old Build:     3 files                            │    │
│  │  ✨ Added in New Build:         5 files                            │    │
│  │  ⚠️ Modified:                   12 files                           │    │
│  │  ✓ Unchanged:                  245 files                           │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  MODIFIED FILES                                                             │
│  ───────────────────────────────────────────────────────────────────────   │
│  ┌──────────────────────────────────────┬─────────┬─────────┬──────────┐   │
│  │ File Name                            │ Old Size│ New Size│ Change   │   │
│  ├──────────────────────────────────────┼─────────┼─────────┼──────────┤   │
│  │ UIFClient-10.25.0.pb00.jar          │ 4.02 MB │ 4.03 MB │ +0.01 MB │   │
│  │ UIFCommon-10.25.0.pb00.jar          │ 392 KB  │ 393 KB  │ +1 KB    │   │
│  │ config/application.properties        │ 2.1 KB  │ 2.3 KB  │ +0.2 KB  │   │
│  └──────────────────────────────────────┴─────────┴─────────┴──────────┘   │
│                                                                              │
│  [📥 Download Report]  [🖨️ Print]  [📋 Copy to Clipboard]                  │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 8. Use Cases & Scenarios

## Use Case 1: Hotfix Verification

**Scenario:** Verify a hotfix contains only the intended changes

```
┌─────────────────────────────────────────────────────────────────┐
│  HOTFIX VERIFICATION WORKFLOW                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. Developer creates hotfix for bug #12345                     │
│     └── Expected change: CustomerService.class only             │
│                                                                  │
│  2. Build team creates patch bundle                             │
│     └── ASCF_HF_v10.25.0.pb00_hf01.zip                         │
│                                                                  │
│  3. QA uses comparison tool:                                    │
│     • Old: ASCF_HF_v10.25.0.pb00                               │
│     • New: ASCF_HF_v10.25.0.pb00_hf01                          │
│     • Mode: Full Content Comparison                             │
│                                                                  │
│  4. Verify results:                                             │
│     ✓ Only CustomerService.class modified                       │
│     ✓ No unintended changes                                     │
│     ✓ Hotfix approved for deployment                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Use Case 2: Release Comparison

**Scenario:** Compare two major releases to understand scope of changes

```
┌─────────────────────────────────────────────────────────────────┐
│  RELEASE COMPARISON WORKFLOW                                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Compare: v10.24.0 → v10.25.0                                   │
│                                                                  │
│  Step 1: Archive Contents Comparison                            │
│     └── Understand structural changes                           │
│                                                                  │
│  Step 2: Naming Convention Comparison                           │
│     └── Identify library version changes                        │
│                                                                  │
│  Step 3: FOSS/Foundation Comparison                             │
│     └── Check for security-related updates                      │
│                                                                  │
│  Output:                                                        │
│  • 15 new features added (new JARs)                            │
│  • 8 libraries upgraded                                         │
│  • 2 security vulnerabilities patched                          │
│  • 145 files modified                                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Use Case 3: Security Audit

**Scenario:** Verify critical security libraries are updated

```
┌─────────────────────────────────────────────────────────────────┐
│  SECURITY AUDIT WORKFLOW                                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Requirement: Ensure Log4j upgraded to 2.17.1+                  │
│                                                                  │
│  1. Select FOSS/Foundation mode                                 │
│  2. Set FOSS Product filter: "log4j"                           │
│  3. Run comparison                                              │
│                                                                  │
│  Results:                                                       │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Component     │ Old Version │ New Version │ Status      │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │ log4j-api     │ 2.14.1      │ 2.17.1      │ ✓ UPGRADED │   │
│  │ log4j-core    │ 2.14.1      │ 2.17.1      │ ✓ UPGRADED │   │
│  │ log4j-1.2-api │ 2.14.1      │ 2.17.1      │ ✓ UPGRADED │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Audit Result: PASSED - All Log4j components updated           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Use Case 4: Deployment Verification

**Scenario:** Ensure deployed package matches approved build

```
┌─────────────────────────────────────────────────────────────────┐
│  DEPLOYMENT VERIFICATION WORKFLOW                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. Copy deployed package from server                           │
│     └── Use built-in Copy utility                               │
│                                                                  │
│  2. Compare with approved build                                 │
│     • Folder 1: Approved build from release                     │
│     • Folder 2: Deployed package from server                    │
│                                                                  │
│  3. Expected Result:                                            │
│     ┌─────────────────────────────────────────────────────┐    │
│     │  ✓ 100% Match - Deployment verified                 │    │
│     │                                                      │    │
│     │  Files compared: 2,847                              │    │
│     │  Identical: 2,847                                   │    │
│     │  Different: 0                                       │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

# 9. Multi-User & Network Access

## Network Deployment Model

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        NETWORK DEPLOYMENT                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│                    ┌────────────────────────────┐                           │
│                    │     SERVER MACHINE         │                           │
│                    │                            │                           │
│                    │  ┌──────────────────────┐ │                           │
│                    │  │  builtin_server.py   │ │                           │
│                    │  │  Port: 5000          │ │                           │
│                    │  │  Host: 0.0.0.0       │ │                           │
│                    │  └──────────────────────┘ │                           │
│                    │                            │                           │
│                    │  IP: 10.78.39.213         │                           │
│                    └─────────────┬──────────────┘                           │
│                                  │                                          │
│            ┌─────────────────────┼─────────────────────┐                   │
│            │                     │                     │                   │
│            ▼                     ▼                     ▼                   │
│   ┌─────────────────┐   ┌─────────────────┐   ┌─────────────────┐        │
│   │   Developer 1   │   │    QA Tester    │   │ Release Manager │        │
│   │                 │   │                 │   │                 │        │
│   │ Browser → URL:  │   │ Browser → URL:  │   │ Browser → URL:  │        │
│   │ 10.78.39.213:   │   │ 10.78.39.213:   │   │ 10.78.39.213:   │        │
│   │ 5000            │   │ 5000            │   │ 5000            │        │
│   └─────────────────┘   └─────────────────┘   └─────────────────┘        │
│                                                                              │
│   Each user gets their own session - no interference between users         │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Benefits of Network Access

| Benefit | Description |
|---------|-------------|
| **No Installation** | Users only need a browser |
| **Centralized Updates** | Update once, everyone gets new version |
| **Shared Resources** | Access to builds stored on server |
| **Collaboration** | Team can access same tool simultaneously |
| **Audit Trail** | Server logs all operations |

## Access Instructions for Team Members

```
┌─────────────────────────────────────────────────────────────────┐
│              QUICK ACCESS GUIDE FOR TEAM                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Step 1: Open your web browser (Chrome, Firefox, Edge)          │
│                                                                  │
│  Step 2: Enter the URL provided by your administrator:          │
│          http://[SERVER_IP]:5000                                │
│          Example: http://10.78.39.213:5000                      │
│                                                                  │
│  Step 3: Start using the tool - no login required               │
│                                                                  │
│  Note: If the URL doesn't work:                                 │
│        • Verify you're on the same network as the server        │
│        • Check with administrator for updated IP address        │
│        • Ensure firewall allows port 5000                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

# 10. Security Considerations

## Data Security

| Aspect | Implementation |
|--------|----------------|
| **Data Storage** | Files are processed in memory; temporary files cleaned up |
| **Network Traffic** | HTTP (consider HTTPS for sensitive environments) |
| **Authentication** | None by default (add reverse proxy for auth if needed) |
| **Access Control** | Controlled by network access to server |

## Best Practices

```
┌─────────────────────────────────────────────────────────────────┐
│              SECURITY BEST PRACTICES                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. Run server on internal network only                         │
│     └── Don't expose to public internet                         │
│                                                                  │
│  2. Use firewall rules                                          │
│     └── Restrict port 5000 to authorized users/IPs              │
│                                                                  │
│  3. For sensitive environments:                                 │
│     └── Add HTTPS via reverse proxy (nginx/Apache)              │
│     └── Add authentication layer                                │
│                                                                  │
│  4. Regular maintenance:                                        │
│     └── Update Python and dependencies                          │
│     └── Review server logs periodically                         │
│                                                                  │
│  5. File system permissions:                                    │
│     └── Restrict access to build folders                        │
│     └── Use read-only access where possible                     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

# 11. Getting Started

## Prerequisites

- Windows 10/11 or Windows Server
- Python 3.8 or higher installed
- Network access (for multi-user setup)
- Web browser (Chrome, Firefox, or Edge recommended)

## Quick Start Guide

```
┌─────────────────────────────────────────────────────────────────┐
│              QUICK START (5 MINUTES)                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Step 1: Navigate to tool folder                                │
│          C:\PythonProject_UPDATED\python_project                │
│                                                                  │
│  Step 2: Double-click START_SERVER.bat                          │
│                                                                  │
│  Step 3: Wait for startup message:                              │
│          "[OK] Built-in server running at http://0.0.0.0:5000"  │
│                                                                  │
│  Step 4: Open browser and go to:                                │
│          http://localhost:5000                                  │
│                                                                  │
│  Step 5: Enter folder paths and click "Run comparison"          │
│                                                                  │
│  Done! You're now using the Patch Comparison Tool.              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Server Management Scripts

| Script | Purpose |
|--------|---------|
| `START_SERVER.bat` | Start the server |
| `STOP_SERVER.bat` | Stop the server |
| `CHECK_STATUS.bat` | Check if server is running |
| `SERVER_MANAGER.bat` | Interactive management menu |

---

# 12. FAQ

## General Questions

**Q: Do users need to install anything?**
> No. Users only need a web browser. The tool runs on a central server.

**Q: How many users can use it simultaneously?**
> The tool supports multiple concurrent users. Each user gets an isolated session.

**Q: What file types can be compared?**
> Folders, ZIP, JAR, WAR, EAR, TAR, TAR.GZ, TGZ, and RPM files.

**Q: Can it compare files on network drives?**
> Yes, but local paths are faster. Use the Copy utility for best performance.

## Technical Questions

**Q: Why is the comparison slow?**
> Large archives with deep nesting take longer. Consider using Naming Convention mode for quick checks.

**Q: Can I compare folders on different machines?**
> Yes, if both folders are accessible from the server (via network paths or copying).

**Q: How do I update the tool?**
> Replace the Python files on the server and restart. No client updates needed.

**Q: Can I run multiple instances?**
> Yes, use different ports: `--port 5001`, `--port 5002`, etc.

## Troubleshooting

**Q: "Address already in use" error?**
> Run STOP_SERVER.bat first, then START_SERVER.bat.

**Q: Browser shows "Connection refused"?**
> Server is not running. Start it with START_SERVER.bat.

**Q: Can't access from another computer?**
> Check firewall settings and verify correct IP address.

---

# Contact & Support

For technical support or feature requests, contact the development team.

---

**Document Version:** 1.0  
**Last Updated:** December 2024  
**Tool Version:** ASCF Patch Comparison Tool v1.0

