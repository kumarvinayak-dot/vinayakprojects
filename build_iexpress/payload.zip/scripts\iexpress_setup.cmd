@echo off
setlocal EnableDelayedExpansion
title ASCF Compare Tool - Setup
echo.
echo ============================================================
echo   ASCF Compare Tool - Setup (localhost only)
echo ============================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "PAYLOAD_ZIP=%SCRIPT_DIR%payload.zip"
set "DEFAULT_DIR=%LOCALAPPDATA%\Amdocs\ASCF_Compare_Tool"
set "INSTALL_DIR=%DEFAULT_DIR%"
set "TEMP_PAYLOAD=%TEMP%\ASCF_Compare_Payload_%RANDOM%"

echo Default install folder:
echo   %DEFAULT_DIR%
echo.
set /p CUSTOM_DIR=Press Enter to accept, or type another folder path: 
if not "%CUSTOM_DIR%"=="" set "INSTALL_DIR=%CUSTOM_DIR%"

if not exist "%PAYLOAD_ZIP%" (
    echo [ERROR] payload.zip not found next to setup: %PAYLOAD_ZIP%
    pause
    exit /b 1
)

echo.
echo [1/5] Locating Python 3.10+...
set "PY_EXE="
for %%C in (py -3 py -3.11 py -3.10 python python3) do (
    if not defined PY_EXE (
        for /f "delims=" %%P in ('%%C -c "import sys; print(sys.executable)" 2^>nul') do set "PY_EXE=%%P"
    )
)
if not defined PY_EXE (
    echo [ERROR] Python 3.10+ not found. Install from python.org and check Add Python to PATH.
    pause
    exit /b 1
)
echo        Using: %PY_EXE%

echo [2/5] Extracting application files...
if exist "%TEMP_PAYLOAD%" rmdir /S /Q "%TEMP_PAYLOAD%"
mkdir "%TEMP_PAYLOAD%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%PAYLOAD_ZIP%' -DestinationPath '%TEMP_PAYLOAD%' -Force"
if errorlevel 1 (
    echo [ERROR] Failed to extract payload.zip
    pause
    exit /b 1
)

echo [3/5] Copying to %INSTALL_DIR% ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
robocopy "%TEMP_PAYLOAD%" "%INSTALL_DIR%" /E /XD .venv __pycache__ .git /XF *.pyc /NFL /NDL /NJH /NJS /nc /ns /np
if errorlevel 8 (
    echo [ERROR] File copy failed.
    rmdir /S /Q "%TEMP_PAYLOAD%" 2>nul
    pause
    exit /b 1
)
rmdir /S /Q "%TEMP_PAYLOAD%" 2>nul

echo [4/5] Creating virtual environment and installing packages...
if not exist "%INSTALL_DIR%\.venv\Scripts\python.exe" (
    "%PY_EXE%" -m venv "%INSTALL_DIR%\.venv"
    if errorlevel 1 (
        echo [ERROR] venv creation failed.
        pause
        exit /b 1
    )
)
"%INSTALL_DIR%\.venv\Scripts\python.exe" -m pip install --upgrade pip -q
if exist "%INSTALL_DIR%\requirements.txt" (
    "%INSTALL_DIR%\.venv\Scripts\python.exe" -m pip install -r "%INSTALL_DIR%\requirements.txt"
    if errorlevel 1 (
        echo [WARN] pip install had errors - check network/proxy.
    )
)

echo [5/5] Creating shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop'); $sm=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\ASCF Compare Tool'; New-Item -ItemType Directory -Force -Path $sm | Out-Null; ^
   $w=New-Object -ComObject WScript.Shell; ^
   $s=$w.CreateShortcut((Join-Path $d 'ASCF Compare Tool - Start.lnk')); $s.TargetPath='%INSTALL_DIR%\start_server.bat'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Save(); ^
   $s=$w.CreateShortcut((Join-Path $d 'ASCF Compare Tool - Open.lnk')); $s.TargetPath='http://localhost:5000/crm'; $s.Save(); ^
   $s=$w.CreateShortcut((Join-Path $sm 'Start Server.lnk')); $s.TargetPath='%INSTALL_DIR%\start_server.bat'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Save(); ^
   $s=$w.CreateShortcut((Join-Path $sm 'Stop Server.lnk')); $s.TargetPath='%INSTALL_DIR%\STOP_SERVER.bat'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Save()"

echo.
echo Installation complete.
echo   Folder: %INSTALL_DIR%
echo   Start:  Desktop shortcut "ASCF Compare Tool - Start"
echo   URL:    http://localhost:5000/crm
echo.
echo The server runs on this PC only (localhost). No network URLs.
echo.
pause
