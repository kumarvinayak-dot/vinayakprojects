# ASCF Compare Tool — Installation Instructions

**For Amdocs Windows users (localhost-only mode)**

Each user installs and runs the tool **on their own PC**. The server listens on **localhost only** (`127.0.0.1`). Other computers cannot connect. No shared network HTTP/HTTPS URLs are used.

---

## What you receive

Your team lead shares one file:

| File | Purpose |
|------|---------|
| **`ASCF_Compare_Tool_Setup.exe`** | One-click installer for your PC |

Optional: this document (`INSTALL_INSTRUCTIONS.md`).

---

## Before you install

| Requirement | Details |
|-------------|---------|
| **PC** | Amdocs-managed Windows 10 or 11 (64-bit) |
| **Python** | **3.10 or newer** must be installed ([python.org](https://www.python.org/downloads/)) — check **“Add Python to PATH”** during install |
| **Disk space** | ~50 GB free on **C:** for large build comparisons |
| **Network** | Access to corporate NAS/build paths (e.g. `\\ntnet\...`, `\\INPNQASCFLB02\...`) |
| **Browser** | Chrome or Edge |
| **Optional** | `C:\cfr-0.152.jar` for Java source diff in CRM reports |

---

## Install (one time)

1. Copy **`ASCF_Compare_Tool_Setup.exe`** to your Amdocs PC (e.g. Desktop or Downloads).
2. **Double-click** `ASCF_Compare_Tool_Setup.exe`.
3. If Windows SmartScreen appears, choose **More info → Run anyway** (internal tool).
4. At the prompt, press **Enter** to accept the default folder:
   ```
   C:\Users\<you>\AppData\Local\Amdocs\ASCF_Compare_Tool
   ```
   Or type a different local path (avoid OneDrive-synced folders).
5. Wait for the installer to finish (copies files, creates virtual environment, installs packages). This may take **5–15 minutes** depending on network speed.
6. When you see **Installation complete**, press Enter.

**Desktop shortcuts created:**

- **ASCF Compare Tool - Start** — starts the server
- **ASCF Compare Tool - Open** — opens the tool in your browser

**Start Menu:** `ASCF Compare Tool` → Start Server / Stop Server / Open Tool

---

## Use the tool (every day)

1. Double-click **ASCF Compare Tool - Start** on your Desktop.
2. Wait a few seconds — your browser should open automatically.
3. If it does not, open manually:
   ```
   http://localhost:5000/crm
   ```
4. Run your ASCF/CRM comparisons as usual.
5. To stop the server, use **Stop Server** from the Start Menu or run `STOP_SERVER.bat` in the install folder.

---

## Install folder location

Default:

```
C:\Users\<YourUsername>\AppData\Local\Amdocs\ASCF_Compare_Tool
```

Important files:

| File | Purpose |
|------|---------|
| `start_server.bat` | Start server (localhost only) |
| `STOP_SERVER.bat` | Stop server |
| `CHECK_STATUS.bat` | Check if server is running |
| `INSTALL_MANIFEST.txt` | Install date and paths |
| `Uninstall ASCF Compare Tool.bat` | Remove the tool |

---

## Optional: HTTPS (self-signed)

For Environment Validation (SSH password over HTTPS):

1. Open PowerShell in the install folder.
2. Run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\generate_https_cert.ps1
   ```
3. Restart with **ASCF Compare Tool - Start**.
4. Use: `https://localhost:5443/crm` (browser may warn about self-signed certificate).

---

## Uninstall

1. Stop the server (**Stop Server** shortcut or `STOP_SERVER.bat`).
2. Run **`Uninstall ASCF Compare Tool.bat`** in the install folder.
3. Type **YES** when prompted.

---

## Troubleshooting

### “Python 3.10+ not found”

Install Python from [python.org](https://www.python.org/downloads/) and enable **Add Python to PATH**, then run the installer again.

### Browser shows “Can’t reach this page”

1. Run **ASCF Compare Tool - Start** again.
2. Run `CHECK_STATUS.bat` in the install folder.
3. Confirm you use **`http://localhost:5000/crm`** (not an IP address or another PC’s name).

### Port 5000 already in use

1. Run `STOP_SERVER.bat`.
2. Start again with **ASCF Compare Tool - Start**.

### pip install fails (no internet / proxy)

Ask your team lead for offline wheel packages and manual setup (see `LOCAL_USER_SETUP.md` in the project).

---

## Security notes

- The tool binds to **127.0.0.1 only** — not accessible from other PCs on the network.
- No shared network URLs are displayed or required.
- Do not copy `.venv` or `.env` from another user’s machine.

---

## For team leads: build the installer

On a development machine with the full `python_project` source:

```cmd
cd python_project
py -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt pyinstaller
BUILD_INSTALLER.bat
```

Output: **`dist\ASCF_Compare_Tool_Setup.exe`** — distribute this file to users with this instruction document.

---

## Support

Contact your ASCF/CRM build team lead for access to build paths, offline packages, or install issues.
