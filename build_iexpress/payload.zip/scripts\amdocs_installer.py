#!/usr/bin/env python3
"""
ASCF Compare Tool — Windows installer (build with PyInstaller to ASCF_Compare_Tool_Setup.exe).

Installs the tool to the user's PC for localhost-only use on the Amdocs network.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

APP_NAME = "ASCF Compare Tool"
DEFAULT_INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", "")) / "Amdocs" / "ASCF_Compare_Tool"
MIN_PYTHON = (3, 10)

EXCLUDE_DIR_NAMES = {
    ".venv",
    ".git",
    "__pycache__",
    "build",
    "dist",
    "logs",
    "temp_compare",
    "agent-transcripts",
    "mcps",
    ".cursor",
    "release_staging",
}

EXCLUDE_FILE_SUFFIXES = {".pyc", ".pyo", ".spec"}


def _is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def _payload_root() -> Path:
    if _is_frozen():
        return Path(getattr(sys, "_MEIPASS", "")) / "payload"
    return Path(__file__).resolve().parent.parent


def _log(msg: str) -> None:
    print(msg, flush=True)


def _pause_on_error(code: int = 1) -> None:
    if _is_frozen():
        input("\nPress Enter to exit...")
    raise SystemExit(code)


def find_python_executable() -> Path | None:
    candidates: list[list[str]] = [
        ["py", "-3"],
        ["py", "-3.11"],
        ["py", "-3.10"],
        ["python"],
        ["python3"],
    ]
    for cmd in candidates:
        try:
            result = subprocess.run(
                [*cmd, "-c", "import sys; print(sys.executable)"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                continue
            exe = Path(result.stdout.strip())
            if not exe.is_file():
                continue
            ver = subprocess.run(
                [str(exe), "-c", "import sys; print(sys.version_info[:2])"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if ver.returncode != 0:
                continue
            parts = ver.stdout.strip().strip("()").replace(" ", "").split(",")
            if len(parts) >= 2:
                major, minor = int(parts[0]), int(parts[1])
                if (major, minor) >= MIN_PYTHON:
                    return exe
        except (OSError, subprocess.SubprocessError, ValueError):
            continue
    return None


def should_skip_path(path: Path) -> bool:
    name = path.name
    if name in EXCLUDE_DIR_NAMES:
        return True
    if name.startswith(".") and name not in {".ssl"}:
        if path.is_dir() or name in {".env"}:
            return True
    if path.suffix.lower() in EXCLUDE_FILE_SUFFIXES:
        return True
    if name == "ASCF_Compare_Tool_Setup.exe":
        return True
    return False


def copy_payload(source: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for item in sorted(source.iterdir()):
        if should_skip_path(item):
            continue
        dest = target / item.name
        if item.is_dir():
            shutil.copytree(
                item,
                dest,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"),
                dirs_exist_ok=True,
            )
        else:
            shutil.copy2(item, dest)


def run_command(cmd: list[str], cwd: Path | None = None) -> None:
    _log(f"  > {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(cmd)}")


def setup_venv(install_dir: Path, python_exe: Path) -> Path:
    venv_python = install_dir / ".venv" / "Scripts" / "python.exe"
    if venv_python.is_file():
        _log("[INFO] Existing virtual environment found — reusing.")
        return venv_python

    _log("[3/6] Creating Python virtual environment...")
    run_command([str(python_exe), "-m", "venv", str(install_dir / ".venv")], cwd=install_dir)
    if not venv_python.is_file():
        raise RuntimeError(f"venv creation failed: {venv_python}")
    run_command([str(venv_python), "-m", "pip", "install", "--upgrade", "pip"], cwd=install_dir)
    req = install_dir / "requirements.txt"
    if req.is_file():
        _log("[4/6] Installing Python packages (may take a few minutes)...")
        run_command([str(venv_python), "-m", "pip", "install", "-r", str(req)], cwd=install_dir)
    else:
        _log("[WARN] requirements.txt not found — skipping pip install.")
    return venv_python


def create_shortcut(shortcut_path: Path, target: Path, arguments: str, work_dir: Path) -> None:
    ps = f"""
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut('{shortcut_path}')
$Shortcut.TargetPath = '{target}'
$Shortcut.Arguments = '{arguments}'
$Shortcut.WorkingDirectory = '{work_dir}'
$Shortcut.Description = '{APP_NAME}'
$Shortcut.Save()
"""
    subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
        check=True,
        timeout=30,
    )


def create_shortcuts(install_dir: Path) -> None:
    _log("[5/6] Creating Desktop and Start Menu shortcuts...")
    desktop = Path(os.environ.get("USERPROFILE", "")) / "Desktop"
    start_menu = (
        Path(os.environ.get("APPDATA", ""))
        / "Microsoft"
        / "Windows"
        / "Start Menu"
        / "Programs"
        / APP_NAME
    )
    start_menu.mkdir(parents=True, exist_ok=True)

    start_bat = install_dir / "start_server.bat"
    stop_bat = install_dir / "STOP_SERVER.bat"

    create_shortcut(desktop / f"{APP_NAME} - Start.lnk", start_bat, "", install_dir)
    create_shortcut(desktop / f"{APP_NAME} - Open.lnk", Path("http://localhost:5000/crm"), "", install_dir)
    create_shortcut(start_menu / "Start Server.lnk", start_bat, "", install_dir)
    create_shortcut(start_menu / "Stop Server.lnk", stop_bat, "", install_dir)
    create_shortcut(start_menu / "Open Tool (Browser).lnk", Path("http://localhost:5000/crm"), "", install_dir)


def write_uninstaller(install_dir: Path) -> None:
    uninstall_bat = install_dir / "Uninstall ASCF Compare Tool.bat"
    uninstall_bat.write_text(
        f"""@echo off
title Uninstall {APP_NAME}
echo.
echo This removes shortcuts and the install folder:
echo   {install_dir}
echo.
echo Stop the server first (run STOP_SERVER.bat).
echo.
set /p CONFIRM=Type YES to uninstall:
if /I not "%CONFIRM%"=="YES" exit /b 1
call "%~dp0STOP_SERVER.bat" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Remove-Item -LiteralPath '$env:USERPROFILE\\Desktop\\{APP_NAME} - Start.lnk' -ErrorAction SilentlyContinue; ^
   Remove-Item -LiteralPath '$env:USERPROFILE\\Desktop\\{APP_NAME} - Open.lnk' -ErrorAction SilentlyContinue; ^
   Remove-Item -Recurse -Force '$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\{APP_NAME}' -ErrorAction SilentlyContinue"
cd /d "%TEMP%"
rmdir /S /Q "{install_dir}"
echo Done.
pause
""",
        encoding="utf-8",
    )


def write_install_manifest(install_dir: Path, python_exe: Path) -> None:
    manifest = install_dir / "INSTALL_MANIFEST.txt"
    manifest.write_text(
        "\n".join(
            [
                f"{APP_NAME} — install manifest",
                f"Installed: {datetime.now().isoformat(timespec='seconds')}",
                f"Location: {install_dir}",
                f"Python: {python_exe}",
                "Mode: localhost only (127.0.0.1)",
                "Start: double-click Desktop shortcut or start_server.bat",
                "URL: http://localhost:5000/crm",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def prompt_install_dir(default: Path) -> Path:
    _log("")
    _log(f"Default install folder: {default}")
    try:
        answer = input("Press Enter to accept, or type a different folder path: ").strip()
    except EOFError:
        answer = ""
    if not answer:
        return default
    return Path(answer)


def main() -> int:
    _log("=" * 60)
    _log(f"  {APP_NAME} — Setup")
    _log("  Localhost-only install for Amdocs Windows PCs")
    _log("=" * 60)
    _log("")

    payload = _payload_root()
    if not payload.is_dir():
        _log(f"[ERROR] Installer payload not found: {payload}")
        _pause_on_error(1)

    install_dir = prompt_install_dir(DEFAULT_INSTALL_DIR)
    install_dir.mkdir(parents=True, exist_ok=True)

    _log("[1/6] Locating Python 3.10+ on this PC...")
    python_exe = find_python_executable()
    if not python_exe:
        _log("[ERROR] Python 3.10+ not found.")
        _log("        Install from https://www.python.org/downloads/")
        _log("        Check 'Add Python to PATH' during installation.")
        _pause_on_error(1)
    _log(f"       Using: {python_exe}")

    _log("[2/6] Copying application files...")
    copy_payload(payload, install_dir)

    try:
        setup_venv(install_dir, python_exe)
        create_shortcuts(install_dir)
        write_uninstaller(install_dir)
        write_install_manifest(install_dir, python_exe)
    except Exception as exc:
        _log(f"[ERROR] Installation failed: {exc}")
        _pause_on_error(1)

    _log("")
    _log("[6/6] Installation complete!")
    _log("")
    _log(f"  Install folder: {install_dir}")
    _log("  Desktop shortcuts created:")
    _log(f"    - {APP_NAME} - Start")
    _log(f"    - {APP_NAME} - Open")
    _log("")
    _log("  Next steps:")
    _log(f"    1. Double-click '{APP_NAME} - Start' on your Desktop")
    _log("    2. Your browser opens http://localhost:5000/crm")
    _log("    3. Use STOP_SERVER.bat or the Start Menu shortcut to stop")
    _log("")
    _log("  The server runs on this PC only — no shared network URLs.")
    _log("=" * 60)

    if _is_frozen():
        input("\nPress Enter to close...")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
