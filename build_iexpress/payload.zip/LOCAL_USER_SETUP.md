# Local User Setup Guide

**Build Verification (NAS) and Environment Validation (HOST IP) Automation Tool**  
ASCF / CRM / AMSS / UXF / OMNI / DEX

Use this guide to install and run the tool **on your own Windows PC** (localhost only).  
Each user runs their own copy — no shared server or access token is required for this mode.

---

## 1. What you need

| Requirement | Details |
|-------------|---------|
| **OS** | Windows 10 or 11 (64-bit) |
| **Python** | 3.10 or newer (3.11+ recommended). [python.org](https://www.python.org/downloads/) — check **“Add Python to PATH”** during install |
| **Disk space** | ~50 GB free on **C:** for large build comparisons (files copy locally during compare) |
| **Network** | Access to corporate NAS/build paths (e.g. `\\ntnet\indiafilestore1\cm_share\...`) |
| **Browser** | Chrome or Edge (recommended) |
| **Optional** | Java JDK — for some decompile features |
| **Optional** | `cfr-0.152.jar` at `C:\cfr-0.152.jar` — for Java source diff in CRM reports |

---

## 2. Get the project

Your team lead will share the project by **Git** or **ZIP**.

**Do not copy these from someone else’s machine** (they are created locally):

- `.venv\` — Python virtual environment  
- `.env` — secrets (not needed for local use)  
- `logs\`, `temp_compare\`, `__pycache__\`  
- Personal comparison reports on `C:\` or in the project folder  

**Suggested install location:**

```
C:\tools\python_project
```

Avoid **OneDrive-synced Desktop** folders if possible (long paths and sync can slow comparisons).

---

## 3. One-time setup

Open **Command Prompt** or **PowerShell** and run:

```cmd
cd C:\tools\python_project

py -m venv .venv

.\.venv\Scripts\pip install --upgrade pip

.\.venv\Scripts\pip install -r requirements.txt
```

**If `pip install` fails (no internet / proxy):** ask your team lead for offline wheel packages and use:

- `install_flask_offline.bat`  
- `scripts\install_paramiko_offline.ps1` (only if you use **Environment Validation** over SSH)

**Verify Python:**

```cmd
.\.venv\Scripts\python.exe --version
```

---

## 4. Start the tool (every time)

1. Double-click **`start_server.bat`** in the project folder.  
2. Wait a few seconds — your browser should open automatically.  
3. If it does not, open:

   ```
   http://localhost:5000/crm
   ```

   Or, if HTTPS certificates exist in `.ssl\`:

   ```
   https://localhost:5443/crm
   ```

**Stop the server:** double-click **`STOP_SERVER.bat`**

**Check status:** double-click **`CHECK_STATUS.bat`**

> **Note:** `start_server.bat` runs on **localhost only** (`127.0.0.1`). Other PCs cannot connect to your machine. No access token is required.

---

## 5. Optional: HTTPS (self-signed)

To reduce browser warnings for Environment Validation (SSH password):

```powershell
cd C:\tools\python_project
powershell -ExecutionPolicy Bypass -File scripts\generate_https_cert.ps1
```

Then restart with `start_server.bat` and use `https://localhost:5443/crm`.

---

## 6. How to use the UI

1. Open **`http://localhost:5000/crm`**
2. Enable **Build Comparison** and pick an application tab (CRM, ASCF, UXF, etc.).
3. Enter **Old build path** and **New build path** (UNC paths from NAS, or use copy-paste helpers in the UI).
4. Click **Run comparison**.
5. Watch progress in **Console Output**; the HTML report opens when finished.
6. **Browse reports** from the home page or under `\\YOURPC\c$\crm_compare_reports` (saved on your PC).

**Environment Validation (optional):**

- Separate panel on the home page — can run while a build comparison is in progress in another tab.
- Requires SSH access to the target Linux host and the path to JARs on that host.

---

## 7. Network paths and permissions

- You must have **read access** to NAS folders you compare (e.g. `\\ntnet\indiafilestore1\cm_share\...`).
- If Explorer cannot open a path, the tool cannot compare it either.
- Comparisons copy packages to **`\\YOURPC\c$\crm_compare_temp`** — keep **~50 GB free on C:**.
- If access fails, map a drive:  
  `net use Z: \\server\share /persistent:yes`

---

## 8. Optional: Java decompiler (CRM Java diffs)

For Java source-level diffs in CRM reports:

1. Download **CFR 0.152** (`cfr-0.152.jar`).
2. Place it at: **`C:\cfr-0.152.jar`**  
   Or set environment variable: `CFR_JAR=C:\path\to\cfr-0.152.jar`

---

## 9. Troubleshooting

| Problem | What to do |
|---------|------------|
| **Python not found** | Reinstall Python with “Add to PATH”, or use `py` instead of `python` |
| **`.venv\Scripts\python.exe` not found** | Repeat step 3 (create venv) |
| **`Address already in use` (port 5000)** | Run `STOP_SERVER.bat`, then `start_server.bat` again |
| **Access denied on NAS path** | Confirm VPN/network; open path in Explorer first |
| **Comparison very slow** | Normal for large builds; ensure free space on C: |
| **Environment Validation / SSH fails** | Install paramiko offline; use HTTPS URL; confirm host/user/password |
| **Browser shows “Access denied” JSON** | You opened a LAN URL with token settings — use `http://localhost:5000/crm` only |

---

## 10. Quick reference

| Action | File / URL |
|--------|------------|
| Start (local) | `start_server.bat` |
| Stop | `STOP_SERVER.bat` |
| Status | `CHECK_STATUS.bat` |
| App URL | `http://localhost:5000/crm` |
| Reports on your PC | `\\YOURPC\c$\crm_compare_reports` |
| Temp during compare | `\\YOURPC\c$\crm_compare_temp` |

---

## 11. What not to use (local users)

These are for **shared Windows Server** deployment only — **not** needed on your laptop:

- `INSTALL_PERSISTENT_SERVER.bat`  
- `start_server_lan.bat`  
- `.env` / `CRM_API_TOKEN`  

For local use, **`start_server.bat`** is enough.

---

## 12. Support

1. Check console output via **Console Output** in the UI.  
2. Ask your team lead for the latest project ZIP/Git link.  
3. Share the **report HTML** and **Console Output** (not passwords) when reporting issues.

---

*Last updated for local (localhost) deployment — each user runs their own instance.*
