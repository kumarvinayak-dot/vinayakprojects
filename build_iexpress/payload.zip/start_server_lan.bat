@echo off
title ASCF Server - LAN mode (deprecated)
echo.
echo ============================================================
echo   DEPRECATED: Shared network access is no longer supported.
echo   Use start_server.bat for localhost-only access on your PC.
echo   Run ASCF_Compare_Tool_Setup.exe to install on an Amdocs machine.
echo ============================================================
echo.
pause
