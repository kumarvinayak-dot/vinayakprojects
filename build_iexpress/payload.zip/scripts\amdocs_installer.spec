# PyInstaller spec for ASCF_Compare_Tool_Setup.exe
# Run BUILD_INSTALLER.bat from the project root.

import sys
from pathlib import Path

block_cipher = None
project_root = Path(SPECPATH).resolve().parent
staging = project_root / "release_staging"
if not staging.is_dir():
    raise SystemExit(
        f"Missing {staging}. Run scripts/build_installer.ps1 first to create release_staging."
    )

a = Analysis(
    [str(project_root / "scripts" / "amdocs_installer.py")],
    pathex=[str(project_root)],
    binaries=[],
    datas=[(str(staging), "payload")],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="ASCF_Compare_Tool_Setup",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
