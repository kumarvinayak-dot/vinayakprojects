#!/usr/bin/env python3
"""Regression: ClfyAgent container rollup for added/removed nested JARs."""

import io
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from crm_compare import CRMComparisonResult, CRMFolderComparer


def _write_zip(path: Path, entries: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w") as zf:
        for name, data in entries.items():
            zf.writestr(name, data)


def test_clfy_container_prefixes_from_class_paths():
    c = CRMFolderComparer("", "")
    prefixes = c._clfy_container_prefixes(
        "ClfyAgent.war!/WEB-INF/lib/removed.jar!/com/example/Foo.class"
    )
    assert "ClfyAgent.war" in prefixes
    assert "ClfyAgent.war!/WEB-INF/lib/removed.jar" in prefixes


def test_container_diff_from_member_sets():
    c = CRMFolderComparer("", "")
    names1 = {"lib/foo.jar!/com/a.class", "lib/bar.jar"}
    names2 = {"lib/bar.jar!/com/b.class"}
    diff = c._clfy_build_container_diff_from_members(names1, names2, [])
    assert "lib/foo.jar" in diff["container_only_old"], diff

    cidx = c._clfy_archive_diff_container_index(
        {
            "container_only_old": diff["container_only_old"],
            "container_only_new": diff["container_only_new"],
            "container_different": diff["container_different"],
        }
    )
    assert cidx["metrics_ext"][".jar"]["oo"] == 1
    assert len(cidx["rows"]) == 1


def test_clfy_container_index_omits_content_diff_by_default():
    c = CRMFolderComparer("", "")
    cidx = c._clfy_archive_diff_container_index(
        {
            "container_only_old": {"lib/removed.jar"},
            "container_only_new": {"lib/added.jar"},
            "container_different": {"lib/changed.jar"},
        }
    )
    status_keys = {r["status_key"] for r in cidx["rows"]}
    assert status_keys == {"only_old", "only_new"}
    assert cidx["metrics_ext"][".jar"]["df"] == 0
    assert not any(r["path"] == "lib/changed.jar" for r in cidx["rows"])

    cidx_all = c._clfy_archive_diff_container_index(
        {
            "container_only_old": set(),
            "container_only_new": set(),
            "container_different": {"lib/changed.jar"},
        },
        include_content_diff=True,
    )
    assert any(r["status_key"] == "different" for r in cidx_all["rows"])


def test_container_diff_detects_removed_nested_jar_via_class_expansion():
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        old_zip = td_path / "old.zip"
        new_zip = td_path / "new.zip"

        inner_removed = io.BytesIO()
        with zipfile.ZipFile(inner_removed, "w") as ij:
            ij.writestr("com/example/Foo.class", b"class-bytes-old")

        _write_zip(
            old_zip,
            {
                "ClfyAgent.war": inner_removed.getvalue(),
                "lib/unchanged.jar": b"PK\x03\x04placeholder",
            },
        )
        _write_zip(
            new_zip,
            {
                "lib/unchanged.jar": b"PK\x03\x04placeholder",
            },
        )

        c = CRMFolderComparer(str(old_zip), str(new_zip))
        c.deep_nested_archives = True
        diff = c._compare_archive_contents(old_zip, new_zip, skip_unbalanced_shallow_rebalance=True)

        assert diff["container_only_old"], "expected removed WAR/JAR in container_only_old"
        assert any(
            "removed.jar" in p or "ClfyAgent.war" in p
            for p in diff["container_only_old"]
        )

        cidx = c._clfy_archive_diff_container_index(diff)
        assert cidx["metrics_ext"][".war"]["oo"] >= 1 or cidx["metrics_ext"][".jar"]["oo"] >= 1
        assert cidx["rows"], "report rows should list removed containers"


def test_multi_location_lib_clfyagent_only_on_new():
    """New SDK lib/ClfyAgent.zip additions must appear even when sharedlib/ClfyAgent.zip exists on both."""
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        old_sdk = td_path / "old_sdk.jar"
        new_sdk = td_path / "new_sdk.jar"

        shared_inner = io.BytesIO()
        with zipfile.ZipFile(shared_inner, "w") as zf:
            zf.writestr("readme.txt", b"sharedlib bundle")

        lib_inner = io.BytesIO()
        with zipfile.ZipFile(lib_inner, "w") as zf:
            zf.writestr("spring-aop-6.2.16.jar", b"PK\x03\x04spring-aop")
            zf.writestr("spring-tx.jar", b"PK\x03\x04spring-tx")

        base = "crm/CRM_10.24/CRM10.24.1_ALL/modules/crm/lib"
        _write_zip(
            old_sdk,
            {f"{base}/sharedlib/ClfyAgent.zip": shared_inner.getvalue()},
        )
        _write_zip(
            new_sdk,
            {
                f"{base}/sharedlib/ClfyAgent.zip": shared_inner.getvalue(),
                f"{base}/ClfyAgent.zip": lib_inner.getvalue(),
            },
        )

        c = CRMFolderComparer(str(old_sdk), str(new_sdk))
        c.compare_clfy_agent_zip = True
        c.deep_nested_archives = True
        info1 = c._synthetic_clfy_agent_info(old_sdk)
        info2 = c._synthetic_clfy_agent_info(new_sdk)
        assert info1 and info2
        diff = c._compare_clfy_all_bundle_locations(info1, info2, info1, info2)
        only_new = diff.get("container_only_new") or set()
        only_new_s = " ".join(only_new).lower()
        assert "spring-aop" in only_new_s or "spring-tx" in only_new_s, diff
        assert diff.get("summary_only_new", len(only_new)) >= 1 or len(only_new) >= 1


def test_jar_mismatch_details_dedupe_same_path():
    c = CRMFolderComparer("", "")
    dup_path = "sdk.jar!/crm/lib/ClfyAgent.zip!/spring-aop.jar"
    old = [dup_path] * 70
    new: list[str] = []
    u_old, u_new = c._pair_archive_paths_by_signature(old, new)
    assert len(u_old) == 1, f"expected 1 unique path, got {len(u_old)}"
    assert u_old[0] == dup_path
    assert u_new == []


def test_war_slash_vs_bang_normalizes_identical_class():
    c = CRMFolderComparer("", "")
    slash = (
        "ClfyAgent.war/WEB-INF/lib/gson.jar!/com/google/gson/internal/"
        "$Gson$Preconditions.class"
    )
    bang = (
        "ClfyAgent.war!/WEB-INF/lib/gson.jar!/com/google/gson/internal/"
        "$Gson$Preconditions.class"
    )
    assert c._member_match_key(slash) == c._member_match_key(bang)


def test_merge_clfy_drops_identical_inner_class_from_both_sides():
    c = CRMFolderComparer("", "")
    tail = (
        "ClfyAgent.war!/WEB-INF/lib/gson.jar!/com/google/gson/internal/"
        "$Gson$Preconditions.class"
    )
    host = "crm/CRM_10.24/CRM10.24.1_ALL/modules/crm/lib/ClfyAgent.ear"
    d1 = {"only_in_old": {f"{host}!/{tail}"}, "only_in_new": set()}
    d2 = {
        "only_in_old": set(),
        "only_in_new": {
            f"{host}!/{tail.replace('war!/', 'war/')}"
        },
    }
    merged = c._merge_clfy_archive_diffs([d1, d2])
    assert not merged.get("only_in_old"), merged
    assert not merged.get("only_in_new"), merged


def test_inner_member_report_skips_identical_gson_class():
    c = CRMFolderComparer("", "")
    tail = (
        "ClfyAgent.war/WEB-INF/lib/gson.jar!/com/google/gson/internal/"
        "$Gson$Preconditions.class"
    )
    host = "crm/CRM_10.24/CRM10.24.1_ALL/modules/crm/lib/ClfyAgent.ear"
    c.clfy_agent_zip_diff = {
        "archive_diff": {
            "only_in_old": {f"{host}!/{tail}"},
            "only_in_new": {
                f"{host}!/{tail.replace('war/', 'war!/')}"
            },
        }
    }
    assert c._collect_inner_jar_member_mismatches([], side="old") == []
    assert c._collect_inner_jar_member_mismatches([], side="new") == []


def test_drop_implicit_meta_inf_maven_directory_markers():
    c = CRMFolderComparer("", "")
    jar = "AmdocsCihxCrmServicesEjbDesc.jar"
    pom = (
        f"{jar}!/META-INF/maven/com.amdocs.crm/"
        f"AmdocsCihxCrmServicesEjbDesc/pom.xml"
    )
    normalized1 = {
        c._normalize_inner_archive_marker(f"{jar}!/META-INF/maven"),
        c._normalize_inner_archive_marker(
            f"{jar}!/META-INF/maven/com.amdocs.crm"
        ),
        c._normalize_inner_archive_marker(pom),
    }
    normalized2 = {c._normalize_inner_archive_marker(pom)}
    common = normalized1 & normalized2
    only_old = normalized1 - normalized2
    dropped = c._drop_implicit_directory_only_members(
        only_old, normalized2, common
    )
    assert c._normalize_inner_archive_marker(pom) in common
    assert dropped == set(), f"expected empty, got {dropped}"


def test_inner_member_report_skips_meta_inf_maven_on_both_builds():
    c = CRMFolderComparer("", "")
    jar = "AmdocsCihxCrmServicesEjbDesc.jar"
    host = "crm/CRM_10.24/CRM10.24.1_ALL/modules/crm/lib/ClfyAgent.ear"
    pom = (
        f"{jar}!/META-INF/maven/com.amdocs.crm/"
        f"AmdocsCihxCrmServicesEjbDesc/pom.xml"
    )
    pom_props = (
        f"{jar}!/META-INF/maven/com.amdocs.crm/"
        f"AmdocsCihxCrmServicesEjbDesc/pom.properties"
    )
    sig_pom = c._jar_inner_file_signature(pom)
    sig_props = c._jar_inner_file_signature(pom_props)
    c.clfy_agent_zip_diff = {
        "archive_diff": {
            "only_in_old": {
                f"{jar}!/META-INF/maven",
                f"{jar}!/META-INF/maven/com.amdocs.crm",
                f"{jar}!/META-INF/maven/com.amdocs.crm/AmdocsCihxCrmServicesEjbDesc",
                pom,
                pom_props,
            },
            "only_in_new": set(),
            "all_member_sig_keys_old": {sig_pom, sig_props},
            "all_member_sig_keys_new": {sig_pom, sig_props},
        }
    }
    rows = c._collect_inner_jar_member_mismatches([], side="old")
    assert rows == [], rows


def test_merge_clfy_drops_meta_inf_when_pom_on_both_sides():
    c = CRMFolderComparer("", "")
    jar = "AmdocsCihxCrmServicesEjbDesc.jar"
    host = "crm/CRM_10.24/CRM10.24.1_ALL/modules/crm/lib/ClfyAgent.ear"
    pom = (
        f"{jar}!/META-INF/maven/com.amdocs.crm/"
        f"AmdocsCihxCrmServicesEjbDesc/pom.xml"
    )
    sig_pom = c._jar_inner_file_signature(pom)
    d1 = {
        "only_in_old": {
            f"{host}!/{jar}!/META-INF/maven",
            f"{host}!/{pom}",
        },
        "only_in_new": set(),
        "all_member_sig_keys_old": {sig_pom},
        "all_member_sig_keys_new": {sig_pom},
    }
    d2 = {
        "only_in_old": set(),
        "only_in_new": {f"{host}!/{jar}!/META-INF/maven/com.amdocs.crm"},
        "all_member_sig_keys_old": {sig_pom},
        "all_member_sig_keys_new": {sig_pom},
    }
    merged = c._merge_clfy_archive_diffs([d1, d2])
    assert not merged.get("only_in_old"), merged
    assert not merged.get("only_in_new"), merged


def test_inner_members_separate_from_container_jar_mismatch():
    """Maven/class paths inside modified JARs must not inflate whole-container jar counts."""
    c = CRMFolderComparer("", "")
    modified = [
        CRMComparisonResult(
            relative_path="lib/spring-core.jar",
            status="modified",
            archive_diff={
                "only_in_old": [
                    "META-INF/maven/org.springframework/spring-core/pom.properties",
                    "META-INF/maven/org.springframework/spring-core/pom.xml",
                    "org/springframework/core/SpringVersion.class",
                ],
                "only_in_new": [],
            },
        )
    ]
    inner_old = c._collect_inner_jar_member_mismatches(modified, side="old")
    assert len(inner_old) == 3, inner_old
    assert all(r["host"] == "lib/spring-core.jar" for r in inner_old)
    kinds = {r["kind"] for r in inner_old}
    assert "class" in kinds
    assert "file" in kinds

    old_paths = c._collect_java_archive_one_side_paths([], [], modified, side="old")
    new_paths = c._collect_java_archive_one_side_paths([], [], modified, side="new")
    assert old_paths == [], f"modified archive should not count as removed container: {old_paths}"
    assert new_paths == []

    d = c._count_delta_details([], [], modified)
    assert int(d["jar_delta"]) == 0
    assert len(d["inner_old_rows"]) == 3
    assert d["jar_rows"] == []

    display = c._jar_mismatch_display_rows(["lib/foo.jar", "other/foo.jar"])
    assert len(display) == 2
    assert display[0]["name"] == "foo.jar"
    assert display[0]["path"] == "lib/foo.jar"
    assert display[1]["path"] == "other/foo.jar"


if __name__ == "__main__":
    test_clfy_container_prefixes_from_class_paths()
    test_container_diff_from_member_sets()
    test_clfy_container_index_omits_content_diff_by_default()
    test_container_diff_detects_removed_nested_jar_via_class_expansion()
    test_multi_location_lib_clfyagent_only_on_new()
    test_jar_mismatch_details_dedupe_same_path()
    test_jar_mismatch_details_dedupe_same_path()
    test_war_slash_vs_bang_normalizes_identical_class()
    test_merge_clfy_drops_identical_inner_class_from_both_sides()
    test_inner_member_report_skips_identical_gson_class()
    test_drop_implicit_meta_inf_maven_directory_markers()
    test_inner_member_report_skips_meta_inf_maven_on_both_builds()
    test_merge_clfy_drops_meta_inf_when_pom_on_both_sides()
    test_inner_members_separate_from_container_jar_mismatch()
    print("OK: clfy container diff tests passed")
