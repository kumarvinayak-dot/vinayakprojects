@echo off
title Build ASCF Compare Tool Setup.exe
echo.
echo Building ASCF_Compare_Tool_Setup.exe using Windows IExpress...
echo No internet required. Output: dist\ASCF_Compare_Tool_Setup.exe
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build_installer_iexpress.ps1"
echo.
pause
