@echo off
setlocal EnableDelayedExpansion
title ASCF Server - Starting...
echo.
echo ============================================================
echo          ASCF Comparison Tool - Starting Server
echo          Localhost only (this PC only)
echo ============================================================
echo.

REM Resolve project path from this script location
set "PROJECT_DIR=%~dp0"
set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"

REM Ports (must match builtin_server.py defaults; HTTPS must differ from HTTP)
set "HTTP_PORT=5000"
set "HTTPS_PORT=5443"
if not "%~1"=="" set "HTTP_PORT=%~1"
if not "%~2"=="" set "HTTPS_PORT=%~2"
set "HOST=127.0.0.1"

REM Use local venv Python for predictable startup
set "PYTHON_EXE=%PROJECT_DIR%\.venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    echo [ERROR] Python not found at: %PYTHON_EXE%
    echo Run ASCF_Compare_Tool_Setup.exe first, or create .venv manually.
    pause
    exit /b 1
)

cd /d "%PROJECT_DIR%"

echo Stopping any listeners on HTTP_PORT %HTTP_PORT% and HTTPS_PORT %HTTPS_PORT%...
for %%P in (%HTTP_PORT% %HTTPS_PORT%) do (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr "LISTENING"') do (
        echo   Killing PID %%a ^(port %%P^)
        taskkill /F /PID %%a >nul 2>&1
    )
)

ping localhost -n 3 >nul 2>&1

set "CFR_JAR=C:\cfr-0.152.jar"
set "HTTPS_PORT=%HTTPS_PORT%"

echo.
echo ============================================================
echo   Server will start in BACKGROUND mode
echo.
echo   HTTP:  http://localhost:%HTTP_PORT%/crm
if exist "%PROJECT_DIR%\.ssl\server.crt" if exist "%PROJECT_DIR%\.ssl\server.key" (
    echo   HTTPS: https://localhost:%HTTPS_PORT%/crm  ^(browser may warn: self-signed cert^)
) else (
    echo   HTTPS: ^(not started — add .ssl\server.crt and .ssl\server.key, or run scripts\generate_https_cert.ps1^)
)
echo.
echo   Access is limited to this PC only. No network URLs are exposed.
echo   To STOP the server, run: STOP_SERVER.bat
echo ============================================================
echo.

start "ASCF Server" /min /D "%PROJECT_DIR%" cmd /c "set CRM_REQUIRE_SECURE=0&& set CRM_OPEN_FIREWALL=0&& "%PYTHON_EXE%" "%PROJECT_DIR%\builtin_server.py" --host %HOST% --port %HTTP_PORT% --https-port %HTTPS_PORT% --https --skip-demos"

echo Server start command issued (HTTP %HTTP_PORT%, HTTPS %HTTPS_PORT% when certs exist^).
echo.

set "SERVER_READY=0"
for /l %%i in (1,1,12) do (
    netstat -ano | findstr ":%HTTP_PORT%" | findstr "LISTENING" >nul
    if errorlevel 1 (
        ping localhost -n 2 >nul
    ) else (
        if exist "%PROJECT_DIR%\.ssl\server.crt" if exist "%PROJECT_DIR%\.ssl\server.key" (
            netstat -ano | findstr ":%HTTPS_PORT%" | findstr "LISTENING" >nul
            if errorlevel 1 (
                ping localhost -n 2 >nul
            ) else (
                set "SERVER_READY=1"
                goto :ready
            )
        ) else (
            set "SERVER_READY=1"
            goto :ready
        )
    )
)

:ready
if "!SERVER_READY!"=="1" (
    echo [SUCCESS] Server is listening on localhost port %HTTP_PORT%
    if exist "%PROJECT_DIR%\.ssl\server.crt" if exist "%PROJECT_DIR%\.ssl\server.key" (
        echo [SUCCESS] HTTPS listening on localhost port %HTTPS_PORT%
        start "" "https://localhost:%HTTPS_PORT%/crm"
    ) else (
        echo [INFO] HTTPS skipped — no certs in .ssl\
        start "" "http://localhost:%HTTP_PORT%/crm"
    )
) else (
    echo [WARNING] Server may still be starting... check Task Manager or run CHECK_STATUS.bat
)

echo.
echo This window will close in 5 seconds...
ping localhost -n 6 >nul 2>&1
