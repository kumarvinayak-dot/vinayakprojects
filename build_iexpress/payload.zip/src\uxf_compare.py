#!/usr/bin/env python3
"""
UXF Application Comparison Module

This module provides comparison functionality specific to UXF application builds.
The comparison logic for UXF is similar to ASCF but maintained separately
to avoid any discrepancy with ASCF comparison behavior.
"""

import os
import re
import html
import zipfile
import tempfile
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from io import BytesIO

# Import decompilation utilities from folder_compare
try:
    from folder_compare import _find_java_decompiler, _decompile_class_file, _compare_decompiled_sources, _extract_class_from_archive
except ImportError:
    # Define fallback functions if import fails
    def _find_java_decompiler():
        """Find available Java decompiler tools."""
        cfr_env = os.environ.get('CFR_JAR', '')
        if cfr_env and os.path.exists(cfr_env):
            return ('cfr', cfr_env)
        
        cfr_paths = [
            os.path.join(os.path.dirname(__file__), 'cfr.jar'),
            os.path.join(os.path.dirname(__file__), '..', 'cfr.jar'),
            os.path.join(os.getcwd(), 'cfr.jar'),
            'C:\\cfr-0.152.jar',
        ]
        
        for cfr_path in cfr_paths:
            if cfr_path and os.path.exists(cfr_path):
                return ('cfr', os.path.abspath(cfr_path))
        
        try:
            result = subprocess.run(['javap', '-version'], capture_output=True, timeout=5)
            if result.returncode == 0:
                return ('javap', 'javap')
        except Exception:
            pass
        
        return (None, None)
    
    def _decompile_class_file(class_bytes, class_name, decompiler_type='javap', decompiler_path=None):
        """Decompile a .class file bytes to Java source."""
        if not class_bytes:
            return (False, "", "Empty class file")
        
        temp_dir = None
        try:
            temp_dir = tempfile.mkdtemp(prefix='class_decompile_')
            simple_name = class_name.split('.')[-1] if '.' in class_name else class_name
            if not simple_name.endswith('.class'):
                simple_name += '.class'
            
            class_file_path = os.path.join(temp_dir, simple_name)
            with open(class_file_path, 'wb') as f:
                f.write(class_bytes)
            
            if decompiler_type == 'cfr' and decompiler_path:
                try:
                    result = subprocess.run(
                        ['java', '-jar', decompiler_path, '--showversion', 'false', '--silent', 'true', class_file_path],
                        capture_output=True, timeout=60, cwd=temp_dir
                    )
                    output = ""
                    for encoding in ['utf-8', 'latin-1', 'cp1252']:
                        try:
                            output = result.stdout.decode(encoding)
                            break
                        except UnicodeDecodeError:
                            continue
                    if output:
                        return (True, output, "")
                    return (False, "", "No output from CFR")
                except Exception as e:
                    return (False, "", f"CFR failed: {str(e)}")
            
            elif decompiler_type == 'javap':
                try:
                    result = subprocess.run(['javap', '-p', '-c', class_file_path], capture_output=True, timeout=30, text=True)
                    if result.returncode == 0:
                        return (True, result.stdout, "")
                    return (False, "", f"javap error: {result.stderr}")
                except Exception as e:
                    return (False, "", f"javap failed: {str(e)}")
            
            return (False, "", "No decompiler available")
        except Exception as e:
            return (False, "", f"Decompilation error: {str(e)}")
        finally:
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                except Exception:
                    pass
    
    def _compare_decompiled_sources(source1, source2, class_name):
        """Compare two decompiled Java sources and generate a diff."""
        import difflib
        
        lines1 = source1.splitlines() if source1 else []
        lines2 = source2.splitlines() if source2 else []
        
        diff = list(difflib.unified_diff(lines1, lines2, fromfile=f'{class_name} (Old)', tofile=f'{class_name} (New)', lineterm=''))
        
        has_diff = len(diff) > 0
        added_lines = sum(1 for line in diff if line.startswith('+') and not line.startswith('+++'))
        removed_lines = sum(1 for line in diff if line.startswith('-') and not line.startswith('---'))
        
        diff_html = []
        if has_diff:
            diff_html.append("<div style='font-family:Consolas,monospace;font-size:11px;background:#1e1e1e;color:#d4d4d4;padding:10px;border-radius:6px;overflow-x:auto;max-height:400px;overflow-y:auto;'>")
            for line in diff[:200]:
                escaped_line = html.escape(line)
                if line.startswith('+++') or line.startswith('---'):
                    diff_html.append(f"<div style='color:#569cd6;font-weight:bold;'>{escaped_line}</div>")
                elif line.startswith('@@'):
                    diff_html.append(f"<div style='color:#c586c0;'>{escaped_line}</div>")
                elif line.startswith('+'):
                    diff_html.append(f"<div style='color:#4ec9b0;background:#1e3a2f;'>{escaped_line}</div>")
                elif line.startswith('-'):
                    diff_html.append(f"<div style='color:#f14c4c;background:#3a1e1e;'>{escaped_line}</div>")
                else:
                    diff_html.append(f"<div>{escaped_line}</div>")
            diff_html.append("</div>")
        
        return {
            'has_diff': has_diff,
            'diff_html': ''.join(diff_html),
            'added_lines': added_lines,
            'removed_lines': removed_lines
        }
    
    def _extract_class_from_archive(archive_path, member_path):
        """Extract a class file from a JAR/ZIP archive."""
        try:
            with zipfile.ZipFile(archive_path, 'r') as zf:
                try:
                    return zf.read(member_path)
                except KeyError:
                    pass
                normalized = member_path.replace('\\', '/')
                try:
                    return zf.read(normalized)
                except KeyError:
                    pass
                target_name = os.path.basename(member_path)
                for name in zf.namelist():
                    if name.endswith(target_name) or os.path.basename(name) == target_name:
                        return zf.read(name)
            return None
        except Exception:
            return None


class UXFComparer:
    """
    UXF-specific folder/build comparer.
    
    This class handles comparison logic that is specific to UXF application builds.
    It scans ZIP/JAR/WAR/EAR archives and compares their contents including class files.
    """
    
    def __init__(self, folder1: str, folder2: str):
        """Initialize UXF comparer with two folder paths."""
        self.folder1 = folder1
        self.folder2 = folder2
        self.results = []
        self.comparison_error = None
        self.suppress_warnings = True
        self.show_missing_only = False
        self.ignore_timestamp_only_differences = True
        
        # Comparison results
        self.archives1 = {}
        self.archives2 = {}
        self.only_in_1 = []
        self.only_in_2 = []
        self.in_both = []
        self.version_changes = []
        self.size_changes = []
        self.truly_new_in_1 = []
        self.truly_new_in_2 = []
        
        # Class file diff results for modified JARs
        self.class_diffs = {}  # {jar_name: [{'class': name, 'diff': diff_result}]}
        
        # Member-level diffs for modified archives (what files changed inside)
        self.member_diffs = {}  # {archive_name: {'added': [], 'removed': [], 'modified': []}}
        
        # Decompiler info
        self.decompiler_type = None
        self.decompiler_path = None
        
        # Session logging and progress callback
        self.log_callback = None
        self.progress_callback = None
        
    def set_log_callback(self, callback):
        """Set a callback function for logging progress"""
        self.log_callback = callback
    
    def set_progress_callback(self, callback):
        """Set a callback function for progress updates: callback(current_file, progress, total)"""
        self.progress_callback = callback
        
    def _log(self, message, level="INFO"):
        """Log a message"""
        print(f"[UXF] [{level}] {message}")
        if self.log_callback:
            self.log_callback(message, level)
    
    def _update_progress(self, current_file, progress=None, total=None):
        """Update progress status"""
        if self.progress_callback:
            self.progress_callback(current_file, progress, total)
    
    def _get_base_name(self, filename):
        """Extract base name without version/build numbers for matching"""
        base = filename
        base = re.sub(r'-\d+\.\d+\.\d+\.[\w\d_.-]+\.(jar|war|ear|zip|rpm)$', '.\\1', base, flags=re.IGNORECASE)
        base = re.sub(r'__V\d+_\d+_\d+_\d+\.(jar|war|ear|zip)$', '.\\1', base, flags=re.IGNORECASE)
        base = re.sub(r'_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}', '', base)
        base = re.sub(r'_\d{8,}', '', base)
        base = re.sub(r'-\d+(\.\d+)*\.(jar|war|ear|zip|rpm)$', '.\\2', base, flags=re.IGNORECASE)
        return base.lower()
    
    def _scan_zip_archive(self, zip_path, prefix=""):
        """Scan a ZIP/JAR/WAR/EAR file and extract all archives and members."""
        all_archives = {}
        
        def get_parent_folder(path):
            parts = path.replace('\\', '/').split('/')
            for i, part in enumerate(parts):
                if part and part != '.' and i < len(parts) - 1:
                    if part.lower() in ['uxf', 'lib', 'web-inf', 'meta-inf', 'classes', 'unsigned_jars', 'signed_jars']:
                        return part
                    if parts[i+1] and os.path.splitext(parts[-1])[1].lower() in ['.jar', '.war', '.ear']:
                        return part
            return os.path.basename(str(zip_path))
        
        def scan_nested(data, parent_name, full_prefix):
            nested = {}
            try:
                with zipfile.ZipFile(BytesIO(data), 'r') as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        filename = os.path.basename(info.filename)
                        ext = os.path.splitext(filename)[1].lower()
                        nested_full_path = f"{full_prefix}{info.filename}"
                        
                        if ext in ['.jar', '.war', '.ear', '.zip']:
                            folder = get_parent_folder(info.filename)
                            nested[filename] = {
                                'full_path': nested_full_path,
                                'size': info.file_size,
                                'crc': info.CRC,
                                'parent': f"{parent_name}/{folder}" if folder != parent_name else parent_name
                            }
                        
                        if ext in ['.war', '.ear', '.zip']:
                            try:
                                deeper_data = zf.read(info.filename)
                                deeper_prefix = f"{nested_full_path}::"
                                deeper = scan_nested(deeper_data, filename, deeper_prefix)
                                nested.update(deeper)
                            except Exception:
                                pass
            except Exception as e:
                pass
            return nested
        
        try:
            self._log(f"Scanning archive: {zip_path}")
            self._update_progress(f"Scanning: {os.path.basename(str(zip_path))}")
            
            with zipfile.ZipFile(str(zip_path), 'r') as zf:
                members = zf.namelist()
                total_members = len(members)
                
                for idx, member in enumerate(members):
                    if idx % 100 == 0:
                        self._update_progress(f"Scanning: {os.path.basename(str(zip_path))} ({idx}/{total_members})", idx, total_members)
                    
                    try:
                        info = zf.getinfo(member)
                    except KeyError:
                        continue
                        
                    if info.is_dir():
                        continue
                    filename = os.path.basename(info.filename)
                    ext = os.path.splitext(filename)[1].lower()
                    full_path = f"{prefix}{info.filename}"
                    
                    if ext in ['.jar', '.war', '.ear', '.zip']:
                        folder = get_parent_folder(info.filename)
                        all_archives[filename] = {
                            'full_path': full_path,
                            'size': info.file_size,
                            'crc': info.CRC,
                            'parent': folder
                        }
                    
                    if ext in ['.war', '.ear', '.zip']:
                        try:
                            nested_data = zf.read(info.filename)
                            nested_prefix = f"{full_path}::"
                            nested = scan_nested(nested_data, filename, nested_prefix)
                            all_archives.update(nested)
                        except Exception as e:
                            pass
            
            self._log(f"Found {len(all_archives)} archives in {os.path.basename(str(zip_path))}")
        except Exception as e:
            self._log(f"Error reading archive {zip_path}: {e}", "ERROR")
            self.comparison_error = str(e)
        
        return all_archives
    
    def _extract_jar_from_archive(self, main_archive_path, jar_full_path):
        """Extract a JAR file from the main archive (handling nested paths)."""
        try:
            parts = jar_full_path.split('::')
            
            with zipfile.ZipFile(str(main_archive_path), 'r') as zf:
                if len(parts) == 1:
                    return zf.read(parts[0])
                else:
                    current_data = zf.read(parts[0])
                    for part in parts[1:]:
                        with zipfile.ZipFile(BytesIO(current_data), 'r') as nested_zf:
                            current_data = nested_zf.read(part)
                    return current_data
        except Exception as e:
            self._log(f"Error extracting JAR {jar_full_path}: {e}", "WARNING")
            return None
    
    def _compare_jar_members(self, jar_name, jar_data1, jar_data2):
        """Compare all members inside two versions of a JAR."""
        member_diff = {'added': [], 'removed': [], 'modified': []}
        
        try:
            with zipfile.ZipFile(BytesIO(jar_data1), 'r') as zf1, \
                 zipfile.ZipFile(BytesIO(jar_data2), 'r') as zf2:
                
                members1 = {n: zf1.getinfo(n) for n in zf1.namelist() if not n.endswith('/')}
                members2 = {n: zf2.getinfo(n) for n in zf2.namelist() if not n.endswith('/')}
                
                set1 = set(members1.keys())
                set2 = set(members2.keys())
                
                # Find added/removed
                member_diff['removed'] = sorted(set1 - set2)
                member_diff['added'] = sorted(set2 - set1)
                
                # Find modified (same name, different size/crc)
                for name in set1 & set2:
                    info1 = members1[name]
                    info2 = members2[name]
                    if info1.file_size != info2.file_size or info1.CRC != info2.CRC:
                        member_diff['modified'].append({
                            'name': name,
                            'old_size': info1.file_size,
                            'new_size': info2.file_size,
                            'old_crc': info1.CRC,
                            'new_crc': info2.CRC
                        })
        except Exception as e:
            self._log(f"Error comparing JAR members in {jar_name}: {e}", "WARNING")
        
        return member_diff
    
    def _compare_jar_class_files(self, jar_name, jar_data1, jar_data2):
        """Compare class files inside two versions of a JAR and return diffs."""
        class_diffs = []
        
        if not self.decompiler_type:
            return class_diffs
        
        try:
            with zipfile.ZipFile(BytesIO(jar_data1), 'r') as zf1, \
                 zipfile.ZipFile(BytesIO(jar_data2), 'r') as zf2:
                
                classes1 = {n: zf1.getinfo(n) for n in zf1.namelist() if n.endswith('.class')}
                classes2 = {n: zf2.getinfo(n) for n in zf2.namelist() if n.endswith('.class')}
                
                common_classes = set(classes1.keys()) & set(classes2.keys())
                modified_classes = []
                
                for class_path in common_classes:
                    info1 = classes1[class_path]
                    info2 = classes2[class_path]
                    if info1.file_size != info2.file_size or info1.CRC != info2.CRC:
                        modified_classes.append(class_path)
                
                # Decompile modified classes (limit to first 10 for performance)
                for i, class_path in enumerate(modified_classes[:10]):
                    self._update_progress(f"Decompiling: {os.path.basename(class_path)}")
                    
                    class_bytes1 = zf1.read(class_path)
                    class_bytes2 = zf2.read(class_path)
                    
                    class_name = os.path.basename(class_path)
                    success1, source1, err1 = _decompile_class_file(
                        class_bytes1, class_name, self.decompiler_type, self.decompiler_path
                    )
                    success2, source2, err2 = _decompile_class_file(
                        class_bytes2, class_name, self.decompiler_type, self.decompiler_path
                    )
                    
                    if success1 and success2:
                        diff_result = _compare_decompiled_sources(source1, source2, class_name)
                        if diff_result['has_diff']:
                            class_diffs.append({
                                'class': class_path,
                                'class_name': class_name,
                                'old_size': classes1[class_path].file_size,
                                'new_size': classes2[class_path].file_size,
                                'diff': diff_result,
                                'source1': source1,
                                'source2': source2
                            })
                
                # Note if there are more modified classes
                if len(modified_classes) > 10:
                    self._log(f"  Note: {len(modified_classes) - 10} more modified class files not decompiled", "INFO")
                    
        except Exception as e:
            self._log(f"Error comparing class files in {jar_name}: {e}", "WARNING")
        
        return class_diffs
        
    def compare_folders(self):
        """Perform UXF-specific folder comparison."""
        self.results = []
        self._log(f"Starting UXF comparison")
        self._log(f"Old Build: {self.folder1}")
        self._log(f"New Build: {self.folder2}")
        self._update_progress("Initializing comparison...", 0, 100)
        
        # Initialize decompiler
        self.decompiler_type, self.decompiler_path = _find_java_decompiler()
        if self.decompiler_type:
            self._log(f"Found decompiler: {self.decompiler_type} at {self.decompiler_path}")
        else:
            self._log("No Java decompiler found - class file diffs will not be available", "WARNING")
        
        p1 = Path(self.folder1)
        p2 = Path(self.folder2)
        
        supported_extensions = ['.zip', '.jar', '.war', '.ear']
        
        self.main_archive1 = None
        self.main_archive2 = None
        
        # Scan first archive
        self._update_progress("Scanning old build...", 5, 100)
        if p1.exists() and p1.is_file() and p1.suffix.lower() in supported_extensions:
            self._log(f"Old Build is an archive: {p1.suffix}")
            self.archives1 = self._scan_zip_archive(p1)
            self.main_archive1 = p1
        elif p1.exists() and p1.is_dir():
            self._log(f"Scanning folder for archives: {p1}")
            for f in p1.rglob('*'):
                if f.is_file() and f.suffix.lower() in supported_extensions:
                    archives = self._scan_zip_archive(f, prefix=f"{f.name}::")
                    self.archives1.update(archives)
                    if self.main_archive1 is None:
                        self.main_archive1 = f
        else:
            self._log(f"Old Build path not found: {self.folder1}", "ERROR")
            self.comparison_error = f"Old Build path not found: {self.folder1}"
            return self.results
        
        # Scan second archive
        self._update_progress("Scanning new build...", 25, 100)
        if p2.exists() and p2.is_file() and p2.suffix.lower() in supported_extensions:
            self._log(f"New Build is an archive: {p2.suffix}")
            self.archives2 = self._scan_zip_archive(p2)
            self.main_archive2 = p2
        elif p2.exists() and p2.is_dir():
            self._log(f"Scanning folder for archives: {p2}")
            for f in p2.rglob('*'):
                if f.is_file() and f.suffix.lower() in supported_extensions:
                    archives = self._scan_zip_archive(f, prefix=f"{f.name}::")
                    self.archives2.update(archives)
                    if self.main_archive2 is None:
                        self.main_archive2 = f
        else:
            self._log(f"New Build path not found: {self.folder2}", "ERROR")
            self.comparison_error = f"New Build path not found: {self.folder2}"
            return self.results
        
        # Compare archives
        self._update_progress("Comparing archives...", 45, 100)
        self._log(f"Comparing {len(self.archives1)} vs {len(self.archives2)} archives")
        
        set1 = set(self.archives1.keys())
        set2 = set(self.archives2.keys())
        
        self.in_both = sorted(set1 & set2)
        exact_only_in_1 = set1 - set2
        exact_only_in_2 = set2 - set1
        
        # Base name matching for version changes
        base_names1 = {self._get_base_name(n): n for n in exact_only_in_1}
        base_names2 = {self._get_base_name(n): n for n in exact_only_in_2}
        
        common_bases = set(base_names1.keys()) & set(base_names2.keys())
        
        for base in common_bases:
            old_name = base_names1[base]
            new_name = base_names2[base]
            self.version_changes.append({
                'old_name': old_name,
                'new_name': new_name,
                'old_info': self.archives1[old_name],
                'new_info': self.archives2[new_name]
            })
            exact_only_in_1.discard(old_name)
            exact_only_in_2.discard(new_name)
        
        self.only_in_1 = sorted(exact_only_in_1)
        self.only_in_2 = sorted(exact_only_in_2)
        self.truly_new_in_1 = self.only_in_1
        self.truly_new_in_2 = self.only_in_2
        
        # Check for size changes in matching archives
        self._update_progress("Finding modified archives...", 55, 100)
        for name in self.in_both:
            info1 = self.archives1[name]
            info2 = self.archives2[name]
            if info1['size'] != info2['size'] or info1['crc'] != info2['crc']:
                self.size_changes.append({
                    'name': name,
                    'old_size': info1['size'],
                    'new_size': info2['size'],
                    'old_crc': info1['crc'],
                    'new_crc': info2['crc'],
                    'old_path': info1['full_path'],
                    'new_path': info2['full_path']
                })
        
        # Analyze modified JARs - compare members and class files
        if self.main_archive1 and self.main_archive2:
            total_modified = len(self.size_changes)
            for idx, sc in enumerate(self.size_changes):
                jar_name = sc['name']
                progress_pct = 60 + int((idx / max(total_modified, 1)) * 30)
                self._update_progress(f"Analyzing: {jar_name}", progress_pct, 100)
                
                if jar_name.lower().endswith('.jar'):
                    self._log(f"  Analyzing: {jar_name}")
                    
                    jar_data1 = self._extract_jar_from_archive(self.main_archive1, sc['old_path'])
                    jar_data2 = self._extract_jar_from_archive(self.main_archive2, sc['new_path'])
                    
                    if jar_data1 and jar_data2:
                        # Compare all members
                        member_diff = self._compare_jar_members(jar_name, jar_data1, jar_data2)
                        if member_diff['added'] or member_diff['removed'] or member_diff['modified']:
                            self.member_diffs[jar_name] = member_diff
                        
                        # Compare class files with decompilation
                        if self.decompiler_type:
                            diffs = self._compare_jar_class_files(jar_name, jar_data1, jar_data2)
                            if diffs:
                                self.class_diffs[jar_name] = diffs
                                self._log(f"    Found {len(diffs)} class file differences")
        
        # Build results
        self._update_progress("Building results...", 95, 100)
        for name in self.only_in_1:
            self.results.append(f"REMOVED: {name}")
        for name in self.only_in_2:
            self.results.append(f"ADDED: {name}")
        for vc in self.version_changes:
            self.results.append(f"VERSION CHANGE: {vc['old_name']} -> {vc['new_name']}")
        for sc in self.size_changes:
            self.results.append(f"MODIFIED: {sc['name']} (size: {sc['old_size']} -> {sc['new_size']})")
        
        self._update_progress("Comparison complete!", 100, 100)
        self._log(f"Comparison complete: {len(self.results)} differences found")
        self._log(f"  - Only in Old: {len(self.only_in_1)}")
        self._log(f"  - Only in New: {len(self.only_in_2)}")
        self._log(f"  - Version Changes: {len(self.version_changes)}")
        self._log(f"  - Size/Content Changes: {len(self.size_changes)}")
        self._log(f"  - Exact Matches: {len(self.in_both)}")
        self._log(f"  - JARs with member diffs: {len(self.member_diffs)}")
        self._log(f"  - JARs with class diffs: {len(self.class_diffs)}")
        
        return self.results
    
    def generate_report(self) -> str:
        """Generate a text report for UXF comparison."""
        lines = []
        lines.append("=" * 80)
        lines.append("UXF BUILD COMPARISON REPORT")
        lines.append("=" * 80)
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Old Build Path: {self.folder1}")
        lines.append(f"New Build Path: {self.folder2}")
        lines.append(f"Decompiler: {self.decompiler_type or 'None'}")
        lines.append("")
        
        if self.comparison_error:
            lines.append("-" * 80)
            lines.append(f"ERROR: {self.comparison_error}")
            lines.append("-" * 80)
        else:
            lines.append("-" * 80)
            lines.append("SUMMARY")
            lines.append("-" * 80)
            lines.append(f"Total archives in Old Build: {len(self.archives1)}")
            lines.append(f"Total archives in New Build: {len(self.archives2)}")
            lines.append(f"Exact matches: {len(self.in_both)}")
            lines.append(f"Only in Old Build: {len(self.only_in_1)}")
            lines.append(f"Only in New Build: {len(self.only_in_2)}")
            lines.append(f"Version Changes: {len(self.version_changes)}")
            lines.append(f"Size/Content Changes: {len(self.size_changes)}")
            lines.append(f"JARs with class diffs: {len(self.class_diffs)}")
            lines.append("")
            
            if self.size_changes:
                lines.append("-" * 80)
                lines.append(f"MODIFIED ARCHIVES ({len(self.size_changes)})")
                lines.append("-" * 80)
                for sc in self.size_changes:
                    size_diff = sc['new_size'] - sc['old_size']
                    lines.append(f"  [M] {sc['name']} ({sc['old_size']} -> {sc['new_size']}, {size_diff:+d} bytes)")
                    
                    # Show member diffs
                    if sc['name'] in self.member_diffs:
                        md = self.member_diffs[sc['name']]
                        if md['added']:
                            lines.append(f"      Added files: {len(md['added'])}")
                        if md['removed']:
                            lines.append(f"      Removed files: {len(md['removed'])}")
                        if md['modified']:
                            lines.append(f"      Modified files: {len(md['modified'])}")
                    
                    if sc['name'] in self.class_diffs:
                        for cd in self.class_diffs[sc['name']]:
                            lines.append(f"      - {cd['class_name']}: +{cd['diff']['added_lines']}/-{cd['diff']['removed_lines']} lines")
                lines.append("")
        
        lines.append("=" * 80)
        lines.append("END OF UXF COMPARISON REPORT")
        lines.append("=" * 80)
        
        return "\n".join(lines)
    
    def generate_html_report(self) -> str:
        """Generate an HTML report for UXF comparison with class file diffs."""
        total_differences = len(self.only_in_1) + len(self.only_in_2) + len(self.version_changes) + len(self.size_changes)
        total_class_diffs = sum(len(diffs) for diffs in self.class_diffs.values())
        total_member_changes = sum(
            len(md['added']) + len(md['removed']) + len(md['modified']) 
            for md in self.member_diffs.values()
        )
        
        decompiler_info = f"🔧 <strong style='color:#48bb78;'>Decompiler: {self.decompiler_type.upper() if self.decompiler_type else 'None'}</strong>"
        
        # Calculate unchanged count
        unchanged_count = len(self.in_both) - len(self.size_changes)
        
        # Build Quick Navigation (ASCF-style with better visibility)
        nav_links = []
        # Always show summary link first
        nav_links.append('<a href="#summary" class="nav-link" style="border-left-color:#6366f1;">📊 Summary</a>')
        
        if self.version_changes:
            nav_links.append(f'<a href="#version-changes" class="nav-link version" style="border-left-color:#f59e0b;">🔄 Version Changes <span class="count">{len(self.version_changes)}</span></a>')
        if self.only_in_1:
            nav_links.append(f'<a href="#only-in-old" class="nav-link removed" style="border-left-color:#ef4444;">🗑️ Removed in New Build <span class="count">{len(self.only_in_1)}</span></a>')
        if self.only_in_2:
            nav_links.append(f'<a href="#only-in-new" class="nav-link added" style="border-left-color:#22c55e;">✨ Added in New Build <span class="count">{len(self.only_in_2)}</span></a>')
        if self.size_changes:
            nav_links.append(f'<a href="#modified" class="nav-link modified" style="border-left-color:#3b82f6;">📝 Modified Archives <span class="count">{len(self.size_changes)}</span></a>')
        if total_class_diffs > 0:
            nav_links.append(f'<a href="#modified" class="nav-link class-diff" style="border-left-color:#8b5cf6;">☕ Class File Diffs <span class="count">{total_class_diffs}</span></a>')
        if unchanged_count > 0:
            nav_links.append(f'<a href="#unchanged" class="nav-link unchanged" style="border-left-color:#10b981;">✓ Unchanged <span class="count">{unchanged_count}</span></a>')
        
        quick_nav_html = f"""
            <div class="nav-menu" id="quick-nav">
                <h3>📑 Quick Navigation</h3>
                <div class="nav-links">
                    {''.join(nav_links)}
                </div>
            </div>"""
        
        # Version changes HTML
        version_changes_html = ""
        if self.version_changes:
            rows = ""
            for vc in self.version_changes:
                rows += f"""<tr>
                    <td style="color:#ef4444;">{html.escape(vc['old_name'])}</td>
                    <td style="text-align:center;">→</td>
                    <td style="color:#22c55e;">{html.escape(vc['new_name'])}</td>
                </tr>"""
            version_changes_html = f"""
            <div class="section" id="version-changes">
                <h2>🔄 Version Changes ({len(self.version_changes)})</h2>
                <table class="comparison-table">
                    <thead><tr><th>Old Version</th><th></th><th>New Version</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>"""
        
        # Only in old HTML
        only_in_1_html = ""
        if self.only_in_1:
            items = "".join([f'<li class="removed">❌ {html.escape(n)}</li>' for n in self.only_in_1])
            only_in_1_html = f"""
            <div class="section" id="only-in-old">
                <h2>❌ Only in Old Build ({len(self.only_in_1)})</h2>
                <ul class="file-list">{items}</ul>
            </div>"""
        
        # Only in new HTML
        only_in_2_html = ""
        if self.only_in_2:
            items = "".join([f'<li class="added">✅ {html.escape(n)}</li>' for n in self.only_in_2])
            only_in_2_html = f"""
            <div class="section" id="only-in-new">
                <h2>✅ Only in New Build ({len(self.only_in_2)})</h2>
                <ul class="file-list">{items}</ul>
            </div>"""
        
        # Modified archives with member and class diffs
        size_changes_html = ""
        if self.size_changes:
            rows = ""
            diff_counter = 0
            
            for sc in self.size_changes:
                size_diff = sc['new_size'] - sc['old_size']
                size_class = "size-increase" if size_diff > 0 else "size-decrease"
                size_str = f"+{size_diff:,}" if size_diff > 0 else f"{size_diff:,}"
                
                diff_counter += 1
                diff_id = f"diff-{diff_counter}"
                
                jar_member_diffs = self.member_diffs.get(sc['name'], {'added': [], 'removed': [], 'modified': []})
                jar_class_diffs = self.class_diffs.get(sc['name'], [])
                
                has_details = jar_member_diffs['added'] or jar_member_diffs['removed'] or jar_member_diffs['modified'] or jar_class_diffs
                
                view_diff_btn = ""
                diff_content = ""
                
                if has_details:
                    view_diff_btn = f"""<button onclick="var d=document.getElementById('{diff_id}');d.style.display=d.style.display==='none'?'block':'none';this.textContent=d.style.display==='none'?'View Diff':'Hide'" style="background:#667eea;color:white;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:11px;">View Diff</button>"""
                    
                    # Build member changes section
                    member_html = ""
                    if jar_member_diffs['added']:
                        items = "".join([f"<div style='color:#22c55e;padding:2px 8px;'>+ {html.escape(m)}</div>" for m in jar_member_diffs['added'][:20]])
                        if len(jar_member_diffs['added']) > 20:
                            items += f"<div style='color:#94a3b8;padding:2px 8px;'>... and {len(jar_member_diffs['added']) - 20} more</div>"
                        member_html += f"""<div style="margin-bottom:10px;">
                            <div style="font-weight:600;color:#22c55e;margin-bottom:5px;">✅ Added Files ({len(jar_member_diffs['added'])})</div>
                            <div style="background:#0f1f0f;border-radius:4px;padding:8px;max-height:150px;overflow:auto;font-size:11px;font-family:Consolas,monospace;">{items}</div>
                        </div>"""
                    
                    if jar_member_diffs['removed']:
                        items = "".join([f"<div style='color:#ef4444;padding:2px 8px;'>- {html.escape(m)}</div>" for m in jar_member_diffs['removed'][:20]])
                        if len(jar_member_diffs['removed']) > 20:
                            items += f"<div style='color:#94a3b8;padding:2px 8px;'>... and {len(jar_member_diffs['removed']) - 20} more</div>"
                        member_html += f"""<div style="margin-bottom:10px;">
                            <div style="font-weight:600;color:#ef4444;margin-bottom:5px;">❌ Removed Files ({len(jar_member_diffs['removed'])})</div>
                            <div style="background:#1f0f0f;border-radius:4px;padding:8px;max-height:150px;overflow:auto;font-size:11px;font-family:Consolas,monospace;">{items}</div>
                        </div>"""
                    
                    if jar_member_diffs['modified']:
                        items = ""
                        for m in jar_member_diffs['modified'][:20]:
                            sz_diff = m['new_size'] - m['old_size']
                            sz_str = f"+{sz_diff}" if sz_diff > 0 else str(sz_diff)
                            items += f"<div style='color:#f59e0b;padding:2px 8px;'>~ {html.escape(m['name'])} ({m['old_size']} → {m['new_size']}, {sz_str})</div>"
                        if len(jar_member_diffs['modified']) > 20:
                            items += f"<div style='color:#94a3b8;padding:2px 8px;'>... and {len(jar_member_diffs['modified']) - 20} more</div>"
                        member_html += f"""<div style="margin-bottom:10px;">
                            <div style="font-weight:600;color:#f59e0b;margin-bottom:5px;">📝 Modified Files ({len(jar_member_diffs['modified'])})</div>
                            <div style="background:#1f1f0f;border-radius:4px;padding:8px;max-height:150px;overflow:auto;font-size:11px;font-family:Consolas,monospace;">{items}</div>
                        </div>"""
                    
                    # Build class diff section
                    class_diff_html = ""
                    if jar_class_diffs:
                        class_items = ""
                        for cd in jar_class_diffs:
                            class_diff_id = f"{diff_id}-{cd['class_name'].replace('.', '-')}"
                            class_items += f"""
                            <div style="margin-bottom:15px;border:1px solid #374151;border-radius:8px;overflow:hidden;">
                                <div style="background:#1e3a5f;color:white;padding:10px;font-weight:600;display:flex;justify-content:space-between;align-items:center;">
                                    <span>☕ {html.escape(cd['class_name'])}</span>
                                    <span><span style="color:#4ade80;">+{cd['diff']['added_lines']}</span> / <span style="color:#f87171;">-{cd['diff']['removed_lines']}</span></span>
                                </div>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;">
                                    <div style="border-right:1px solid #374151;">
                                        <div style="background:#991b1b;color:white;padding:8px;font-size:12px;font-weight:600;">❌ Old Version</div>
                                        <div style="padding:10px;font-size:10px;font-family:Consolas,monospace;max-height:300px;overflow:auto;background:#1e1e1e;color:#d4d4d4;">
                                            {''.join(f"<div style='padding:1px 4px;'>{html.escape(line)}</div>" for line in cd['source1'].split(chr(10))[:80])}
                                        </div>
                                    </div>
                                    <div>
                                        <div style="background:#166534;color:white;padding:8px;font-size:12px;font-weight:600;">✅ New Version</div>
                                        <div style="padding:10px;font-size:10px;font-family:Consolas,monospace;max-height:300px;overflow:auto;background:#1e1e1e;color:#d4d4d4;">
                                            {''.join(f"<div style='padding:1px 4px;'>{html.escape(line)}</div>" for line in cd['source2'].split(chr(10))[:80])}
                                        </div>
                                    </div>
                                </div>
                            </div>"""
                        
                        class_diff_html = f"""<div style="margin-top:15px;">
                            <div style="font-weight:600;color:#8b5cf6;margin-bottom:10px;">☕ Java Class Differences ({len(jar_class_diffs)})</div>
                            {class_items}
                        </div>"""
                    
                    diff_content = f"""<tr><td colspan="5" style="padding:0;border:none;">
                        <div id="{diff_id}" style="display:none;margin:10px;background:#0f172a;border-radius:8px;padding:15px;">
                            {member_html}
                            {class_diff_html}
                        </div>
                    </td></tr>"""
                
                # Summary of what changed
                change_summary = []
                if jar_member_diffs['added']:
                    change_summary.append(f"+{len(jar_member_diffs['added'])} files")
                if jar_member_diffs['removed']:
                    change_summary.append(f"-{len(jar_member_diffs['removed'])} files")
                if jar_member_diffs['modified']:
                    change_summary.append(f"~{len(jar_member_diffs['modified'])} files")
                if jar_class_diffs:
                    change_summary.append(f"{len(jar_class_diffs)} class diffs")
                
                summary_str = ", ".join(change_summary) if change_summary else "Size changed"
                
                rows += f"""<tr class="modified">
                    <td>{html.escape(sc['name'])}</td>
                    <td style="text-align:right;">{sc['old_size']:,}</td>
                    <td style="text-align:right;">{sc['new_size']:,}</td>
                    <td style="text-align:right;" class="{size_class}">{size_str}</td>
                    <td style="text-align:center;font-size:11px;">{summary_str}<br/>{view_diff_btn}</td>
                </tr>{diff_content}"""
            
            size_changes_html = f"""
            <div class="section" id="modified">
                <h2>📝 Modified Archives ({len(self.size_changes)})</h2>
                <p style="color:#6b7280;font-size:13px;margin-bottom:15px;">
                    Total member changes: {total_member_changes} | Class file diffs: {total_class_diffs}
                </p>
                <table class="comparison-table">
                    <thead><tr><th>Archive Name</th><th>Old Size</th><th>New Size</th><th>Diff</th><th>Changes</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>"""
        
        error_html = ""
        if self.comparison_error:
            error_html = f"""
            <div class="error-box">
                <h3>⚠️ Comparison Error</h3>
                <p>{html.escape(self.comparison_error)}</p>
            </div>"""
        
        no_diff_html = ""
        if total_differences == 0 and not self.comparison_error:
            no_diff_html = """
            <div class="success-box">
                <h3>✅ No Differences Found</h3>
                <p>The two builds contain identical archives.</p>
            </div>"""
        
        # Unchanged archives section
        unchanged_html = ""
        if unchanged_count > 0:
            unchanged_items = []
            for name in self.in_both:
                if name not in [sc['name'] for sc in self.size_changes]:
                    unchanged_items.append(name)
            
            if unchanged_items:
                items_html = "".join([f'<li class="unchanged">✓ {html.escape(n)}</li>' for n in sorted(unchanged_items)[:50]])
                more_text = f"<li style='color:#6b7280;font-style:italic;'>... and {len(unchanged_items) - 50} more unchanged archives</li>" if len(unchanged_items) > 50 else ""
                unchanged_html = f"""
            <div class="section" id="unchanged">
                <h2>✓ Unchanged Archives ({unchanged_count})</h2>
                <p style="color:#6b7280;font-size:13px;margin-bottom:15px;">These archives are identical in both builds (same size and CRC).</p>
                <ul class="file-list">{items_html}{more_text}</ul>
            </div>"""
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UXF Build Comparison Report</title>
    <style>
        * {{ box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', system-ui, sans-serif; margin: 0; padding: 20px; background: linear-gradient(135deg, #065f46 0%, #047857 100%); min-height: 100vh; }}
        .container {{ max-width: 1400px; margin: 0 auto; background: white; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); overflow: hidden; }}
        .header {{ background: linear-gradient(135deg, #065f46 0%, #047857 100%); color: white; padding: 30px; }}
        .header h1 {{ margin: 0 0 10px 0; font-size: 28px; }}
        .header .subtitle {{ opacity: 0.9; font-size: 14px; }}
        .header .paths {{ margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.3); }}
        .header .path-label {{ font-weight: 600; font-size: 12px; text-transform: uppercase; opacity: 0.8; margin-top: 8px; }}
        .header .path-value {{ font-family: Consolas, monospace; font-size: 13px; margin-top: 4px; word-break: break-all; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; padding: 20px 30px; background: #f0fdf4; border-bottom: 1px solid #bbf7d0; }}
        .summary-card {{ background: white; padding: 12px; border-radius: 8px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .summary-card .number {{ font-size: 24px; font-weight: 700; color: #065f46; }}
        .summary-card .label {{ font-size: 11px; color: #6b7280; margin-top: 4px; }}
        .decompiler-info {{ padding: 10px 30px; background: #ecfdf5; border-bottom: 1px solid #bbf7d0; font-size: 13px; }}
        .nav-menu {{ background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%); border: 2px solid #86efac; border-radius: 12px; padding: 20px; margin-bottom: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }}
        .nav-menu h3 {{ margin: 0 0 15px 0; color: #065f46; font-size: 18px; font-weight: 700; }}
        .nav-links {{ display: flex; flex-wrap: wrap; gap: 12px; }}
        .nav-link {{ display: inline-flex; align-items: center; gap: 8px; padding: 12px 16px; background: white; border: 1px solid #e2e8f0; border-left: 5px solid #3b82f6; border-radius: 8px; text-decoration: none; color: #1f2937; font-size: 13px; font-weight: 600; transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }}
        .nav-link:hover {{ background: #f8fafc; transform: translateX(4px); border-left-width: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }}
        .nav-link .count {{ background: #e5e7eb; color: #374151; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 700; }}
        .nav-link.removed .count {{ background: #fee2e2; color: #991b1b; }}
        .nav-link.added .count {{ background: #dcfce7; color: #166534; }}
        .nav-link.modified .count {{ background: #dbeafe; color: #1e40af; }}
        .nav-link.version .count {{ background: #fef3c7; color: #92400e; }}
        .nav-link.class-diff .count {{ background: #ede9fe; color: #5b21b6; }}
        .nav-link.unchanged .count {{ background: #d1fae5; color: #065f46; }}
        .content {{ padding: 30px; }}
        .section {{ margin-bottom: 30px; }}
        .section h2 {{ color: #065f46; font-size: 18px; margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #d1fae5; }}
        .comparison-table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
        .comparison-table th {{ background: #065f46; color: white; padding: 12px; text-align: left; }}
        .comparison-table td {{ padding: 10px 12px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }}
        .comparison-table tr:hover {{ background: #f0fdf4; }}
        .file-list {{ list-style: none; padding: 0; margin: 0; max-height: 400px; overflow-y: auto; }}
        .file-list li {{ padding: 8px 12px; border-bottom: 1px solid #e5e7eb; font-family: Consolas, monospace; font-size: 12px; }}
        .file-list li.removed {{ background: #fef2f2; color: #991b1b; }}
        .file-list li.added {{ background: #f0fdf4; color: #166534; }}
        .file-list li.unchanged {{ background: #f8fafc; color: #475569; }}
        .size-increase {{ color: #dc2626; font-weight: 600; }}
        .size-decrease {{ color: #16a34a; font-weight: 600; }}
        .error-box {{ background: #fef2f2; border: 2px solid #fca5a5; border-radius: 8px; padding: 20px; margin-bottom: 20px; }}
        .error-box h3 {{ color: #dc2626; margin: 0 0 10px 0; }}
        .success-box {{ background: #f0fdf4; border: 2px solid #86efac; border-radius: 8px; padding: 20px; margin-bottom: 20px; text-align: center; }}
        .success-box h3 {{ color: #166534; margin: 0 0 10px 0; }}
        .back-link {{ display: inline-block; margin-top: 20px; padding: 10px 20px; background: #065f46; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; }}
        .back-link:hover {{ background: #047857; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎨 UXF Build Comparison Report</h1>
            <div class="subtitle">Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            <div class="paths">
                <div class="path-label">📁 Old Build Path</div>
                <div class="path-value">{html.escape(self.folder1)}</div>
                <div class="path-label">📁 New Build Path</div>
                <div class="path-value">{html.escape(self.folder2)}</div>
            </div>
        </div>
        
        <div class="decompiler-info">{decompiler_info} | ☕ Class diffs: {total_class_diffs} | 📄 Member changes: {total_member_changes}</div>
        
        <div class="summary" id="summary">
            <div class="summary-card"><div class="number">{len(self.archives1)}</div><div class="label">Archives in Old</div></div>
            <div class="summary-card"><div class="number">{len(self.archives2)}</div><div class="label">Archives in New</div></div>
            <div class="summary-card"><div class="number">{len(self.version_changes)}</div><div class="label">Version Changes</div></div>
            <div class="summary-card"><div class="number">{len(self.only_in_1)}</div><div class="label">Only in Old</div></div>
            <div class="summary-card"><div class="number">{len(self.only_in_2)}</div><div class="label">Only in New</div></div>
            <div class="summary-card"><div class="number">{len(self.size_changes)}</div><div class="label">Modified</div></div>
            <div class="summary-card"><div class="number">{unchanged_count}</div><div class="label">Unchanged</div></div>
            <div class="summary-card"><div class="number">{total_class_diffs}</div><div class="label">Class Diffs</div></div>
        </div>
        
        <div class="content">
            {quick_nav_html}
            {error_html}
            {no_diff_html}
            {version_changes_html}
            {only_in_1_html}
            {only_in_2_html}
            {size_changes_html}
            {unchanged_html}
            
            <a href="/" class="back-link">← Back to Home</a>
        </div>
    </div>
</body>
</html>"""
        return html_content
    
    def save_report(self, filepath: str):
        """Save the text report to a file."""
        report = self.generate_report()
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        html_filepath = str(Path(filepath).with_suffix('.html'))
        html_report = self.generate_html_report()
        with open(html_filepath, 'w', encoding='utf-8') as f:
            f.write(html_report)


def run_uxf_comparison(folder1: str, folder2: str, session_id=None, log_callback=None, progress_callback=None, **options) -> tuple:
    """Main entry point for UXF comparison."""
    from report_naming import build_report_filename

    report_user = (
        options.get("report_user")
        or options.get("client_identity")
        or "unknown"
    )
    _rd = Path(str(options.get("report_dir") or "."))
    output_filename = build_report_filename(
        "uxf_patch_comparison", folder1, folder2, report_user, report_dir=_rd
    )
    
    comparer = UXFComparer(folder1, folder2)
    comparer.suppress_warnings = options.get('suppress_warnings', True)
    comparer.show_missing_only = options.get('show_missing_only', False)
    comparer.ignore_timestamp_only_differences = options.get('ignore_timestamp_only', True)
    
    if log_callback:
        comparer.set_log_callback(log_callback)
    if progress_callback:
        comparer.set_progress_callback(progress_callback)
    
    results = comparer.compare_folders()
    
    return comparer, results, output_filename
