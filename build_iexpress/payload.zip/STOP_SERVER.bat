@echo off
setlocal EnableDelayedExpansion
title ASCF Server - Stopping...
echo.
echo ============================================================
echo          ASCF Comparison Tool - Stopping Server
echo          HTTP and HTTPS listeners
echo ============================================================
echo.

REM Same defaults as start_server.bat (optional: STOP_SERVER.bat 5000 5443)
set "HTTP_PORT=5000"
set "HTTPS_PORT=5443"
if not "%~1"=="" set "HTTP_PORT=%~1"
if not "%~2"=="" set "HTTPS_PORT=%~2"

set "FOUND=0"

echo Checking persistent scheduled task CRMCompareToolServer...
schtasks /Query /TN "CRMCompareToolServer" >nul 2>&1
if not errorlevel 1 (
    echo   Ending persistent server task...
    schtasks /End /TN "CRMCompareToolServer" >nul 2>&1
)

for %%P in (%HTTP_PORT% %HTTPS_PORT%) do (
    echo Checking port %%P...
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr "LISTENING"') do (
        set "FOUND=1"
        echo   Stopping PID %%a ^(port %%P^)
        taskkill /F /PID %%a >nul 2>&1
        if not errorlevel 1 (
            echo   [OK] Stopped PID %%a
        ) else (
            echo   [INFO] PID %%a may have already exited
        )
    )
)

if "!FOUND!"=="0" (
    echo [INFO] No listeners on ports %HTTP_PORT% or %HTTPS_PORT%
    echo.
    echo If the server still runs: Task Manager — end "ASCF Server" or python.exe ^(builtin_server^)
)

echo.
echo Done!
timeout /t 3 /nobreak >nul
