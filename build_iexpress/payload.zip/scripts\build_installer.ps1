# Build ASCF_Compare_Tool_Setup.exe (run on a dev machine with Python + internet).
$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path $PSScriptRoot -Parent
$StagingDir = Join-Path $ProjectDir "release_staging"
$DistDir = Join-Path $ProjectDir "dist"
$PythonExe = Join-Path $ProjectDir ".venv\Scripts\python.exe"

if (-not (Test-Path $PythonExe)) {
    throw "Create .venv first: py -m venv .venv && .\.venv\Scripts\pip install -r requirements.txt pyinstaller"
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  Build ASCF_Compare_Tool_Setup.exe (PyInstaller)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/4] Staging application payload..."
if (Test-Path $StagingDir) {
    Remove-Item -Recurse -Force $StagingDir
}
New-Item -ItemType Directory -Path $StagingDir | Out-Null

$ExcludeDirs = @(
    ".venv", ".git", "__pycache__", "build", "dist", "logs", "temp_compare",
    "agent-transcripts", "mcps", ".cursor", "release_staging", "build_iexpress",
    "tmp_cfr_diff", "flask_wheels"
)

Get-ChildItem -Path $ProjectDir -Force | ForEach-Object {
    if ($ExcludeDirs -contains $_.Name) { return }
    if ($_.Name -eq "ASCF_Compare_Tool_Setup.exe") { return }
    if ($_.Name -like "*.pyc") { return }
    if ($_.Name -eq ".env") { return }
    $dest = Join-Path $StagingDir $_.Name
    if ($_.PSIsContainer) {
        Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
    } else {
        Copy-Item -Path $_.FullName -Destination $dest -Force
    }
}

Write-Host "       Payload: $StagingDir"

Write-Host "[2/4] Ensuring PyInstaller is installed..."
& $PythonExe -m pip install --upgrade pyinstaller | Out-Null

Write-Host "[3/4] Building single-file installer..."
Push-Location $ProjectDir
try {
    & $PythonExe -m PyInstaller --noconfirm --clean (Join-Path $ProjectDir "scripts\amdocs_installer.spec")
} finally {
    Pop-Location
}

$SetupExe = Join-Path $DistDir "ASCF_Compare_Tool_Setup.exe"
if (-not (Test-Path $SetupExe)) {
    throw "Build failed - $SetupExe not found."
}

Write-Host "[4/4] Done." -ForegroundColor Green
Write-Host ""
Write-Host "  Output: $SetupExe" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Share this file with Amdocs users along with INSTALL_INSTRUCTIONS.md"
Write-Host ""
