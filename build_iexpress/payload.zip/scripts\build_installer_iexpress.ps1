# Build ASCF_Compare_Tool_Setup.exe using Windows IExpress (no PyInstaller / internet required).
$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path $PSScriptRoot -Parent
$StagingDir = Join-Path $ProjectDir "release_staging"
$DistDir = Join-Path $ProjectDir "dist"
$IExpressDir = Join-Path $ProjectDir "build_iexpress"
$SetupExe = Join-Path $DistDir "ASCF_Compare_Tool_Setup.exe"
$SedFile = Join-Path $IExpressDir "installer.sed"
$PayloadZip = Join-Path $IExpressDir "payload.zip"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  Build ASCF_Compare_Tool_Setup.exe (IExpress)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/5] Staging application payload..."
if (Test-Path $StagingDir) { Remove-Item -Recurse -Force $StagingDir }
New-Item -ItemType Directory -Path $StagingDir | Out-Null

$ExcludeDirs = @(
    ".venv", ".git", "__pycache__", "build", "dist", "logs", "temp_compare",
    "agent-transcripts", "mcps", ".cursor", "release_staging", "build_iexpress",
    "tmp_cfr_diff", "flask_wheels"
)

Get-ChildItem -Path $ProjectDir -Force | ForEach-Object {
    if ($ExcludeDirs -contains $_.Name) { return }
    if ($_.Name -like "ASCF_Compare_Tool_Setup.exe") { return }
    if ($_.Name -like "*.pyc") { return }
    if ($_.Name -eq ".env") { return }
    $dest = Join-Path $StagingDir $_.Name
    if ($_.PSIsContainer) {
        Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
    } else {
        Copy-Item -Path $_.FullName -Destination $dest -Force
    }
}

Write-Host "[2/5] Creating payload.zip..."
if (Test-Path $IExpressDir) { Remove-Item -Recurse -Force $IExpressDir }
New-Item -ItemType Directory -Path $IExpressDir | Out-Null
New-Item -ItemType Directory -Path $DistDir -Force | Out-Null
if (Test-Path $PayloadZip) { Remove-Item -Force $PayloadZip }
Compress-Archive -Path (Join-Path $StagingDir "*") -DestinationPath $PayloadZip -Force

Copy-Item (Join-Path $ProjectDir "scripts\iexpress_setup.cmd") (Join-Path $IExpressDir "setup.cmd") -Force

Write-Host "[3/5] Writing IExpress configuration..."
$PackageDir = "$IExpressDir\"

$sed = @"
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=1
HideExtractAnimation=0
UseLongFileName=1
InsideCompressed=1
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=
FinishMessage=Installation complete. Use the Desktop shortcut to start the tool.
TargetName=$SetupExe
FriendlyName=ASCF Compare Tool Setup
AppLaunched=setup.cmd
PostInstallCmd=<None>
AdminQuietInst=
UserQuietInst=
SourceFiles=SourceFiles
[Strings]
InstallPrompt=Install ASCF Compare Tool on this PC (localhost only)?
[SourceFiles]
SourceFiles0=$PackageDir
[SourceFiles0]
%FILE0%=setup.cmd
%FILE1%=payload.zip
"@

Set-Content -Path $SedFile -Value $sed -Encoding ASCII

Write-Host "[4/5] Running IExpress..."
$iexpress = Join-Path $env:SystemRoot "System32\iexpress.exe"
if (-not (Test-Path $iexpress)) {
    throw "iexpress.exe not found at $iexpress"
}

if (Test-Path $SetupExe) { Remove-Item -Force $SetupExe }
$proc = Start-Process -FilePath $iexpress -ArgumentList "/N", $SedFile -Wait -PassThru -WindowStyle Hidden
Start-Sleep -Seconds 2

Write-Host "[5/5] Verifying output..."
if (-not (Test-Path $SetupExe)) {
    throw "IExpress build failed (exit $($proc.ExitCode)). Expected: $SetupExe"
}

$sizeMb = [math]::Round((Get-Item $SetupExe).Length / 1MB, 1)
Write-Host ""
Write-Host "  Done." -ForegroundColor Green
Write-Host "  Output: $SetupExe ($sizeMb MB)" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Share ASCF_Compare_Tool_Setup.exe with users and INSTALL_INSTRUCTIONS.md"
Write-Host ""
